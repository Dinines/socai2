"""C6 output: final analysis, explicit comparison and scoped Case impact."""
import copy
import json
from typing import Literal
from uuid import UUID

from pydantic import Field, ValidationError

from . import baseline_analysis_contract as analysis
from .baseline_contracts import Contract
from .baseline_model_view import blocked
from .case_citation_quality import normalized, reject_or_record
from .case_source_scope import knowledge_context
from .citation_quality import record_references
from .structured_output import response_format

SCHEMA = "socai2.baseline-delivery.v2"
READ_SCHEMAS = {"socai2.baseline-delivery.v1", SCHEMA}
Text, Refs = analysis.Text, analysis.Refs


class Conclusion(Contract):
    text: Text
    state: Literal["supported", "uncertain"]
    alert_ids: analysis.Members
    support_ids: Refs
    limitations: list[Text] = Field(max_length=12)


class Comparison(Contract):
    kind: Literal["initial", "unchanged", "expanded", "revised", "withdrawn", "not_comparable"]
    summary: Text | None
    support_ids: Refs


class Impact(Contract):
    summary: Text
    alert_ids: list[UUID] = Field(max_length=200)
    support_ids: Refs
    supported_changes: list[Text] = Field(max_length=12)
    cannot_generalize: list[Text] = Field(min_length=1, max_length=12)
    next_steps: list[Text] = Field(max_length=12)


class Recommendation(Contract):
    id: Text
    action_type: Literal["investigate", "contain", "remediate", "monitor"]
    object_keys: Refs
    reason: Text
    source_ids: Refs
    limitations: list[Text] = Field(max_length=12)


class Delivery(Contract):
    analysis: analysis.Analysis
    conclusion: Conclusion
    closing_note: Text
    comparison: Comparison
    impact: Impact
    recommendations: list[Recommendation] = Field(max_length=12)


def comparable_source_ids(source_map, comparison):
    """The designated accepted Result, never a current intermediate judgment."""
    if comparison["state"] != "eligible":
        return set()
    return {sid for sid, src in source_map.items() if src["ref"]["type"] == "result"
            and src["ref"]["id"] == comparison["result_id"]}


def constrain_recommendations(fmt):
    """Tighten generation without breaking partial recovery of invalid replies."""
    schema = fmt["json_schema"]["schema"]
    props = schema["$defs"]["Recommendation"]["properties"]
    array = props["source_ids"]
    while "$ref" in array:
        array = schema["$defs"][array["$ref"].removeprefix("#/$defs/")]
    if array.get("maxItems") == 0:
        recommendations = schema["properties"]["recommendations"]
        while "$ref" in recommendations:
            recommendations = schema["$defs"][recommendations["$ref"].removeprefix("#/$defs/")]
        schema["properties"]["recommendations"] = {**copy.deepcopy(recommendations), "maxItems": 0}
    else:
        props["source_ids"] = {**copy.deepcopy(array), "minItems": 1}
    return fmt


def delivery_format(sources, context, comparison):
    fmt = response_format(Delivery, sources, members=context.alerts,
        questions=[q.id for q in context.questions], objects=context.scope.object_keys)
    if comparison["state"] == "initial" and comparison["result_id"] is None:
        # The first investigation has no prior result to summarize or cite.
        # Narrow only this object's properties, never a shared array definition.
        props = fmt["json_schema"]["schema"]["$defs"]["Comparison"]["properties"]
        props.update(kind={"type": "string", "enum": ["initial"]}, summary={"type": "null"},
            support_ids={"type": "array", "items": {"type": "string"}, "maxItems": 0})
    return constrain_recommendations(fmt)


def parse(content, source_map, context, coverage, comparison, *, citation_review=None):
    path = "$"
    def fail(code):
        reject_or_record(citation_review, code, path)

    def unique(pairs):
        result = {}
        for k, v in pairs:
            if k in result:
                fail("duplicate_json_key")
            result[k] = v
        return result

    try:
        raw = json.loads(content, object_pairs_hook=unique, parse_constant=lambda _: fail("invalid_json_number"))
        raw = normalized(raw, citation_review)
        if blocked(raw):
            fail("delivery_output_guard_blocked")
        def nonblank(item):
            if isinstance(item, str) and not item.strip():
                fail("delivery_blank_text")
            if isinstance(item, dict):
                for key, v in item.items():
                    if key not in {"evidence_ids", "source_ids", "support_ids", "counter_ids", "finding_ids"}:
                        nonblank(v)
            if isinstance(item, list):
                for v in item:
                    nonblank(v)
        nonblank(raw)
        value = Delivery.model_validate(raw)
    except (ValueError, TypeError, ValidationError) as exc:
        if isinstance(exc, analysis.AnalysisRejected):
            raise
        raise analysis.AnalysisRejected("delivery_shape_invalid") from None
    analysis.parse(json.dumps(raw["analysis"]), source_map, context, coverage,
                   citation_review=citation_review, root_path="$.analysis")

    def scope(ids):
        ids = list(map(str, ids))
        if len(ids) != len(set(ids)) or not set(ids) <= set(context.alerts):
            fail("delivery_scope_outside_run_or_duplicate")
        return set(ids)

    def refs(ids, aids=(), *, direct=False, field="support_ids"):
        record_references(citation_review, ids, source_map, path + "." + field, sorted(aids), required=bool(aids))
        if len(ids) != len(set(ids)) or not set(ids) <= set(source_map):
            fail("delivery_source_not_visible_or_duplicate")
        owned = set()
        for sid in (sid for sid in ids if sid in source_map):
            src = source_map[sid]
            if src["ref"]["role"] == "execution_receipt":
                fail("execution_receipt_not_conclusion_evidence")
            if aids and src.get("knowledge") and not knowledge_context(src, aids):
                fail("source_member_mismatch")
            if not src.get("knowledge") and (not direct or (src["ref"]["role"] in {"observation", "human_statement"}
                    and src.get("membership_basis") != "query_binding_only")):
                owned.update(src["alert_ids"])
        if not set(aids) <= owned:
            fail("delivery_source_coverage_missing")

    path = "$.conclusion"
    covered = scope(value.conclusion.alert_ids)
    refs(value.conclusion.support_ids, covered, direct=value.conclusion.state == "supported")
    members = {str(m.alert_id): m for m in value.analysis.members}
    if any(members[a].state == "not_analyzed" for a in covered):
        fail("unanalysed_member_in_conclusion")
    if value.conclusion.state == "uncertain" and not value.conclusion.limitations:
        fail("uncertain_conclusion_needs_limits")
    path = "$.comparison"
    refs(value.comparison.support_ids)
    baseline_ids = comparable_source_ids(source_map, comparison)
    if not comparison["result_id"] and comparison["state"] == "initial":
        if value.comparison.kind != "initial" or value.comparison.summary is not None or value.comparison.support_ids:
            fail("initial_delivery_must_not_invent_comparison")
    elif not baseline_ids:
        if value.comparison.kind != "not_comparable" or not value.comparison.summary:
            fail("comparison_not_available")
    elif value.comparison.kind == "initial" or not value.comparison.summary:
        raise analysis.AnalysisRejected("comparison_needs_selected_baseline_and_current_sources")
    elif (not (baseline_ids & set(value.comparison.support_ids))
            or (value.comparison.kind != "not_comparable" and not (set(value.comparison.support_ids) - baseline_ids))):
        fail("comparison_needs_selected_baseline_and_current_sources")
    path = "$.impact"
    affected = scope(value.impact.alert_ids)
    refs(value.impact.support_ids, affected, direct=bool(value.impact.supported_changes))
    if value.impact.supported_changes and not affected:
        fail("supported_impact_needs_member_scope")
    seen = set()
    for index, item in enumerate(value.recommendations):
        path = f"$.recommendations.{index}"
        if item.id in seen or not set(item.object_keys) <= set(context.scope.object_keys):
            fail("recommendation_identity_or_target_invalid")
        seen.add(item.id)
        refs(item.source_ids, field="source_ids")
        if not item.source_ids:
            fail("recommendation_needs_sources")
    return value


def citation_roles(payload):
    if not isinstance(payload, dict):
        return {}
    if payload.get("type") == "delivery_report" and payload.get("delivery"):
        return {"$.delivery": "prior_analysis", "$.result": "prior_analysis"}
    if "result_id" in payload and "findings" in payload:
        return {"$.conclusion": "prior_analysis", "$.findings": "prior_analysis",
            **{f"$.findings.{i}": "prior_analysis" for i in range(len(payload["findings"]))}}
    return analysis.citation_roles(payload)


PROMPT = f"""C6输出单行紧凑JSON，不调工具，写全recommendations并闭合。
前序失败仍据可见事实汇总；缺证写uncertain及缺口，不推为无风险。
source_groups组内共用角色/成员。observed须本成员直接observation，时间仅作上下文；成员属性不互移。标题/厂商/演练标签不证明授权或良性；未提供审批非无审批，端口不证明应用协议。
analysis覆盖全员/六问/四领域；无资料用not_analyzed/undetermined，列限制/替代解释。identity核认证/MFA/会话/权限/授权；cloud核控制面/IAM/配置/影响；phishing核邮件/链接/附件/投递/点击/执行；insider核数据访问/外传量/目的地/基线/授权。{analysis.DOMAIN_FINDING_SCOPE}非applicable写限制，引用不决定适用性。conflicts仅列至少两条发现的实际矛盾；缺证不算。
supported结论及实际影响须由对应成员的观察或人工陈述支持；旧判断/标签/图/query_binding_only不作直接事实。impact无确定变化填[]，说明不能推广。
comparison限指定result_id：initial用summary=null/support_ids=[]；基线不可用用not_comparable并说明；可比时引用基线和当前来源，区分范围/判断变化。
analysis.followups必填，无新建议填[]；文字及object_keys限alert_ids，跨成员列全。query单次/deep按结果续查/graph关系核验/human人工确认，不写SQL或扩范围。execution_plan_index对应routes.followup_index；其他followup为新提议。completed/answer_available非问题解决，human handoff非人工确认。
建议限已有对象，不声称审批/执行或全文已读；closing_note写认识/待核。limitations用中文短句写本项证据缺口，勿反复抄通用限制码。每段≤50字，结论≤90字；findings≤2/followups≤1/recommendations≤1，各引用保必要1–3项；目标2000tokens。
"""
