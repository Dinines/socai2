"""Frozen public business DTOs plus HTTP-only request bodies. No persistence/execution.

Business DTOs remain shared with callers that execute without HTTP.
"""

from uuid import UUID

from app.socai2.case_story_contracts import StoryPage, StoryQuery
from app.socai2.exploration_contracts import ExplorationPage, ExplorationQuery

from app.socai2.baseline_contracts import (
    Actor,
    Contract,
    Start,
)
from app.socai2.baseline_store import (
    StoreError,
)
from app.socai2.case_adoption_contracts import (
    AssessmentHistory,
    ResultAdoptionPreview,
    ResultAdoptionReceipt,
    ResultAdoptionRequest,
)
from app.socai2.case_ai_contracts import (
    AIUnavailable,
    AskCaseAI,
    SaveCaseAIAnswer,
)
from app.socai2.case_attachment_contracts import (
    CaseAttachmentCreate,
    CaseAttachmentPage,
    CaseAttachmentView,
)
from app.socai2.case_contracts import (
    ArtifactContent,
    AssociationReceipt,
    AssociationRequest,
    BaselinePreparation,
    CaseCreate,
    CaseDetail,
    CaseMetric,
    CaseQueuePage,
    CaseQueueQuery,
    HistoryPage,
    MemberChange,
    MoveMembers,
    MoveReceipt,
    MutationReceipt,
    PrepareBaseline,
    ResultDetail,
    RunDetail,
)
from app.socai2.case_data_contracts import (
    CaseDataReceipt,
    CaseDataUpdate,
    CasePageData,
    Classification,
    EvidencePublish,
)
from app.socai2.case_management_contracts import (
    CaseCloseRequest,
    CaseLifecycleRequest,
    CaseManagementReceipt,
    CaseManagementUpdate,
    CaseManagementView,
)
from app.socai2.enums import (
    AlertStatus,
    AssignmentState,
    Severity,
    WorkStatus,
)
from app.socai2.human_task_contracts import (
    TaskCreate,
    TaskEdit,
    TaskMutation,
    TaskPage,
    TaskRevisionPage,
    TaskRevisionView,
    TaskView,
)
from app.socai2.list_query_contracts import (
    AlertListQuery,
    AlertSort,
    CaseSort,
    IncidentListQuery,
    IncidentSort,
    SortOrder,
)
from app.socai2.page_contracts import (
    ContentView,
    RecordPage,
    Section,
    Subject,
    SubjectPage,
    SubjectView,
    TraceView,
)
from app.socai2.stage_read_contracts import (
    StageEntry,
    StagePage,
)
from app.socai2.subject_management_contracts import (
    AlertFeedback,
    AlertFeedbackBatch,
    AlertManagementBatch,
    AlertManagementUpdate,
    IncidentManagementBatch,
    IncidentManagementUpdate,
    SelectedSubject,
    SubjectBatchReceipt,
    SubjectMutationReceipt,
)


class ExecuteStage(Contract):
    operation_key: UUID


__all__ = [
    "StoryPage",
    "ExplorationPage",
    "ExplorationQuery",
    "StoryQuery",
    "AIUnavailable",
    "Actor",
    "AlertFeedback",
    "AlertFeedbackBatch",
    "AlertListQuery",
    "AlertManagementBatch",
    "AlertManagementUpdate",
    "AlertSort",
    "AlertStatus",
    "ArtifactContent",
    "AskCaseAI",
    "AssessmentHistory",
    "AssignmentState",
    "AssociationReceipt",
    "AssociationRequest",
    "BaselinePreparation",
    "CaseAttachmentCreate",
    "CaseAttachmentPage",
    "CaseAttachmentView",
    "CaseCloseRequest",
    "CaseCreate",
    "CaseDataReceipt",
    "CaseDataUpdate",
    "CaseDetail",
    "CaseLifecycleRequest",
    "CaseManagementReceipt",
    "CaseManagementUpdate",
    "CaseManagementView",
    "CaseMetric",
    "CasePageData",
    "CaseQueuePage",
    "CaseQueueQuery",
    "CaseSort",
    "Classification",
    "ContentView",
    "Contract",
    "EvidencePublish",
    "ExecuteStage",
    "HistoryPage",
    "IncidentListQuery",
    "IncidentManagementBatch",
    "IncidentManagementUpdate",
    "IncidentSort",
    "MemberChange",
    "MoveMembers",
    "MoveReceipt",
    "MutationReceipt",
    "PrepareBaseline",
    "RecordPage",
    "ResultAdoptionPreview",
    "ResultAdoptionReceipt",
    "ResultAdoptionRequest",
    "ResultDetail",
    "RunDetail",
    "SaveCaseAIAnswer",
    "Section",
    "SelectedSubject",
    "Severity",
    "SortOrder",
    "StageEntry",
    "StagePage",
    "Start",
    "StoreError",
    "Subject",
    "SubjectBatchReceipt",
    "SubjectMutationReceipt",
    "SubjectPage",
    "SubjectView",
    "TaskCreate",
    "TaskEdit",
    "TaskMutation",
    "TaskPage",
    "TaskRevisionPage",
    "TaskRevisionView",
    "TaskView",
    "TraceView",
    "WorkStatus",
]

# Existing public facts and read-only export payload for the CSV boundary.
from app.socai2.case_contracts import CaseView
from app.socai2.page_contracts import AlertFacts, IncidentFacts

__all__ += ["AlertFacts", "CaseView", "IncidentFacts"]

from app.socai2.grouping_contracts import GroupingQuery, GroupingSummary

__all__ += ["GroupingQuery", "GroupingSummary"]

from app.socai2.case_comment_contracts import (
    CaseCommentCreate,
    CaseCommentPage,
    CaseCommentView,
)

__all__ += ["CaseCommentCreate", "CaseCommentPage", "CaseCommentView"]

from app.socai2.exploration_state_contracts import (
    ExplorationBase, ExplorationSave, ExplorationSaved, ExplorationSnapshot,
)

__all__ += ["ExplorationBase", "ExplorationSave", "ExplorationSaved", "ExplorationSnapshot"]

from app.socai2.alert_review_contracts import AlertReviewPage, AlertReviewQuery

__all__ += ["AlertReviewPage", "AlertReviewQuery"]

from app.socai2.alert_host_contracts import AlertHostPage

__all__ += ["AlertHostPage"]
