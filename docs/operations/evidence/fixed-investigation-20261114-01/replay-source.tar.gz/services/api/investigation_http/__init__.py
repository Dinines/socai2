"""External investigation HTTP boundary."""
