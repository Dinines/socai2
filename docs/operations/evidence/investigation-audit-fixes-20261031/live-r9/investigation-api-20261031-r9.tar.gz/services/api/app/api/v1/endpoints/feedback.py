"""Analyst override feedback + retroactive re-disposition — Tier 1.5.

Pipeline
--------
1. ``POST /feedback/alert-override`` — analyst corrects an AI verdict.
   * Persists the corrected ``disposition`` on the alert.
   * Records the lesson in ``aisoc_institutional_memory`` (so future
     investigations of similar alerts pull this up).
   * Returns *retroactive candidates* — past alerts in the same tenant
     that share the alert's signature and would now be re-dispositioned.
2. ``POST /feedback/redisposition/apply`` — analyst opts in (or auto-
   applies via UI) to update the disposition on a chosen subset of
   those candidates.
3. ``GET  /feedback/overrides`` — lists every override the agent has
   "learned" for this tenant.
4. ``GET  /feedback/summary`` — counts of dispositions for the FPR card.
5. ``GET  /feedback/context-statements`` — the organisation memory compiled
   from tagged disagreements, which the triage prompt reads.

Organisation memory (``app/services/analyst_feedback.py``)
----------------------------------------------------------
``reason`` on an override is free text, and the module next door exists
because free text does not generalise: nobody queries it, and the next
identical alert is triaged knowing nothing about the last one being
overturned. That module compiles a **closed** reason vocabulary into durable,
readable statements — "PowerShell launched by svc_backup on BACKUP01 is
expected during the 02:00 backup window".

It had no callers. Not one: ``record_disagreement`` was never invoked, so the
table stayed empty, and ``active_statements`` was never read, so an empty
table was never noticed. Both ends are wired here — the optional
``reason_code`` on an override writes, and ``/context-statements`` reads —
because wiring only the read would have been a query against a table nothing
populates, which is the same defect wearing a different hat.

Authorization
-------------
Both writes require ``alerts:write``. They change an alert's ``disposition``
— one alert on an override, a confirmed batch on a re-disposition — which is
the same act ``alerts.py`` already gates on ``alerts:write``, and the two
doors onto that column now agree.

It matters more here than on a single alert. An override is persisted into
institutional memory as a per-signature prior, and a *trusted* benign prior
auto-resolves matching repeat alerts without re-triage. So an ungated
override was not one wrong verdict; it was a durable instruction to the
platform to stop looking, writable by a ``viewer``.

``threat_hunter`` holds no ``alerts:write`` and is therefore refused, which
is consistent with the role's documented posture of handing off rather than
dispositioning.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from datetime import UTC, datetime
from typing import Annotated, Any

import structlog
from fastapi import APIRouter, Depends, Header, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy import and_, func, select, text, update

from app.api.v1.deps import AuthUser, DBSession, require_permission
from app.api.v1.endpoints.alert_writeback import service_token_valid
from app.db.rls import set_rls_context
from app.models.alert import Alert
from app.security.tenant_scope import scoped_tenant_or_403
from app.services import sla_events
from app.services.analyst_feedback import (
    REASON_CODES,
    active_statements,
    record_disagreement,
)
from app.services.human_priors import record_human_prior
from app.services.memory_poisoning import plan_redisposition
from app.services.override_learning import (
    apply_redisposition,
    find_redisposition_candidates,
    list_overrides,
    record_override,
)

logger = structlog.get_logger()

router = APIRouter(prefix="/feedback", tags=["feedback"])

# ``benign_true_positive`` (#526): a valid detection of authorized/expected
# activity. Kept distinct from ``false_positive`` so BTP never inflates a rule's
# false-positive rate. Existing ``benign`` records stay valid (no migration).
_VALID_VERDICTS = {
    "true_positive",
    "benign_true_positive",
    "false_positive",
    "benign",
    "escalate",
}


def _statement_context(alert: Alert) -> dict[str, Any]:
    """The facts a compiled statement is allowed to name.

    Scoping is the whole point of the taxonomy: a `binary`-scoped reason keys
    on the process, an `entity`-scoped one on the principal or host, a
    `rule`-scoped one on the rule. Handing over a thin context produces
    "PowerShell is expected", which is a suppression waiting to hide an
    incident rather than a fact.

    The alert row denormalises host and user into `affected_hosts` /
    `affected_users` lists and carries process and hash only inside
    `raw_event`, so both are read here rather than assumed to be columns.
    """
    raw = alert.raw_event if isinstance(alert.raw_event, dict) else {}

    def _from_raw(*keys: str) -> str | None:
        for key in keys:
            value = raw.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()[:256]
        return None

    def _first(values: object) -> str | None:
        if isinstance(values, list):
            for value in values:
                if isinstance(value, str) and value.strip():
                    return value.strip()[:256]
        return None

    return {
        "rule_id": alert.rule_id,
        "rule_name": alert.rule_name,
        "hostname": _first(alert.affected_hosts) or _from_raw("hostname", "host"),
        "user_name": _first(alert.affected_users) or _from_raw("username", "user"),
        "process_name": _from_raw("process_name", "process", "image", "exe"),
        "hash_sha256": _from_raw("sha256", "file_hash"),
    }


def _coerce_uuid(value: str, field: str) -> uuid.UUID:
    try:
        return uuid.UUID(value)
    except (TypeError, ValueError) as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"{field} must be a valid UUID",
        ) from exc


class AlertOverrideRequest(BaseModel):
    alert_id: str
    original_verdict: str = Field(..., description="The AI-generated verdict being overridden")
    corrected_verdict: str = Field(
        ...,
        description="Analyst's verdict: true_positive | benign_true_positive | false_positive | benign | escalate",
    )
    reason: str | None = Field(None, description="Optional free-text justification")
    reason_code: str | None = Field(
        None,
        description=(
            "Optional code from the closed disagreement vocabulary "
            "(known_admin_tool, approved_pentest, expected_service_account, "
            "known_scanner, business_application, bad_detection_logic, "
            "missing_context, true_positive_confirmed). Supplying one lets the "
            "platform compile durable organisation memory from repeated "
            "disagreement; free text alone cannot generalise."
        ),
    )


class RedispositionCandidateModel(BaseModel):
    alert_id: str
    title: str
    severity: str
    current_disposition: str | None
    proposed_disposition: str
    event_time: str


class AlertOverrideResponse(BaseModel):
    alert_id: str
    corrected_verdict: str
    recorded_at: str
    memory_key: str | None = None
    redisposition_candidates: list[RedispositionCandidateModel] = Field(default_factory=list)
    # Blast-radius controls for retroactive apply (Phase 1.2). The client must
    # echo confirmation_token back to /redisposition/apply; quarantined means a
    # poisoning flag or over-cap match requires human clearance before apply.
    redisposition_confirmation_token: str | None = None
    redisposition_capped: bool = False
    redisposition_quarantined: bool = False
    redisposition_total_matched: int = 0
    #: The organisation-memory statement this disagreement completed, if it
    #: crossed the corroboration threshold. ``None`` means recorded but not yet
    #: trusted — one analyst calling one alert benign is an opinion.
    context_statement: str | None = None


@router.post("/alert-override", response_model=AlertOverrideResponse)
async def submit_alert_override(
    payload: AlertOverrideRequest,
    user: Annotated[AuthUser, Depends(require_permission("alerts:write"))],
    db: DBSession,
) -> AlertOverrideResponse:
    """Record an analyst verdict correction on an alert and surface
    retroactive re-disposition candidates."""
    if payload.corrected_verdict not in _VALID_VERDICTS:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"corrected_verdict must be one of: {', '.join(sorted(_VALID_VERDICTS))}",
        )
    if payload.reason_code is not None and payload.reason_code not in REASON_CODES:
        # Refused rather than silently ignored: an analyst who mistypes a code
        # would otherwise believe they had taught the platform something.
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"reason_code must be one of: {', '.join(sorted(REASON_CODES))}",
        )
    alert_uuid = _coerce_uuid(payload.alert_id, "alert_id")

    alert = await db.scalar(
        select(Alert).where(
            Alert.id == alert_uuid,
            Alert.tenant_id == user.tenant_id,
        )
    )
    if alert is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alert not found",
        )

    now = datetime.now(UTC)
    await db.execute(
        update(Alert)
        .where(Alert.id == alert_uuid, Alert.tenant_id == user.tenant_id)
        .values(disposition=payload.corrected_verdict, updated_at=now)
    )
    # A disposition is the analyst declaring the alert resolved, which is
    # the `resolved` half of every SLA figure. `alert_sla_events` had one
    # writer — a manual POST nothing calls — so `services/sla.py` computed
    # MTTD, MTTR and MTTC over an empty table on every deployment.
    await sla_events.record_event(
        db,
        alert_id=alert_uuid,
        tenant_id=user.tenant_id,
        event_type="resolved",
        actor_id=user.user_id,
        occurred_at=now,
        metadata={"disposition": payload.corrected_verdict},
    )
    await db.commit()

    # A human reached this verdict on this evidence, so record a
    # human-authored outcome prior under the key the triage worker looks up.
    # Before this, `record_outcome` was called from three agents-side workers
    # and from nowhere an analyst could reach, so every prior in the system
    # was AI-authored and v15's "AI priors never suppress" rule meant repeat
    # suppression could not fire on anything at all.
    prior_signature = await record_human_prior(
        db,
        tenant_id=user.tenant_id,
        alert=alert,
        disposition=payload.corrected_verdict,
        analyst_id=user.user_id,
        reason=payload.reason,
    )
    if prior_signature:
        await db.commit()

    # Persist into institutional memory.
    signature = await record_override(
        db,
        tenant_id=user.tenant_id,
        alert=alert,
        original_verdict=payload.original_verdict,
        corrected_verdict=payload.corrected_verdict,
        analyst_id=user.user_id,
        reason=payload.reason,
    )

    # Find similar past alerts that would now disposition differently.
    candidates: list[RedispositionCandidateModel] = []
    memory_key: str | None = None
    plan = None
    if signature is not None:
        memory_key = signature.memory_key()
        raw_candidates = await find_redisposition_candidates(
            db,
            tenant_id=user.tenant_id,
            signature=signature,
            corrected_verdict=payload.corrected_verdict,
            exclude_alert_id=alert_uuid,
        )
        candidates = [RedispositionCandidateModel(**c.to_dict()) for c in raw_candidates]
        plan = plan_redisposition(
            [c.alert_id for c in raw_candidates],
            payload.corrected_verdict,
        )

    # Structured disagreement, when the analyst tagged one. Fails soft: the
    # override itself is already committed above and is the operator-visible
    # outcome, so a memory-compilation problem must not turn a successful
    # correction into a 500.
    statement_text: str | None = None
    if payload.reason_code:
        try:
            statement = await record_disagreement(
                db,
                tenant_id=user.tenant_id,
                alert_id=alert_uuid,
                ai_disposition=payload.original_verdict,
                analyst_disposition=payload.corrected_verdict,
                reason_code=payload.reason_code,
                analyst_id=str(user.user_id),
                context=_statement_context(alert),
                note=payload.reason or "",
            )
            await db.commit()
            statement_text = statement.statement if statement else None
        except Exception as exc:  # noqa: BLE001 — never fail a recorded override
            await db.rollback()
            logger.warning(
                "analyst.disagreement_not_recorded",
                tenant_id=str(user.tenant_id),
                reason_code=payload.reason_code,
                error=str(exc),
            )

    logger.info(
        "analyst.override",
        tenant_id=str(user.tenant_id),
        alert_id=payload.alert_id,
        analyst_id=str(user.user_id),
        original_verdict=payload.original_verdict,
        corrected_verdict=payload.corrected_verdict,
        reason=payload.reason,
        memory_key=memory_key,
        candidate_count=len(candidates),
        recorded_at=now.isoformat(),
    )

    return AlertOverrideResponse(
        alert_id=payload.alert_id,
        corrected_verdict=payload.corrected_verdict,
        recorded_at=now.isoformat(),
        memory_key=memory_key,
        redisposition_candidates=candidates,
        redisposition_confirmation_token=plan.confirmation_token if plan else None,
        redisposition_capped=plan.capped if plan else False,
        redisposition_quarantined=plan.quarantined if plan else False,
        redisposition_total_matched=plan.total_matched if plan else 0,
        context_statement=statement_text,
    )


class RedispositionApplyRequest(BaseModel):
    alert_ids: list[str]
    new_disposition: str
    confirmation_token: str = Field(
        ...,
        description="Token from the /alert-override preview over this exact alert set (Phase 1.2 blast-radius control)",
    )


class RedispositionApplyResponse(BaseModel):
    updated: int
    new_disposition: str


@router.post("/redisposition/apply", response_model=RedispositionApplyResponse)
async def apply_redisposition_endpoint(
    payload: RedispositionApplyRequest,
    user: Annotated[AuthUser, Depends(require_permission("alerts:write"))],
    db: DBSession,
) -> RedispositionApplyResponse:
    """Bulk-update the disposition on past alerts the analyst confirmed.

    Requires the confirmation token from the preview; a stale/tampered set or a
    batch over the cap is rejected rather than silently flipping history.
    """
    if payload.new_disposition not in _VALID_VERDICTS:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"new_disposition must be one of: {', '.join(sorted(_VALID_VERDICTS))}",
        )
    if not payload.alert_ids:
        return RedispositionApplyResponse(updated=0, new_disposition=payload.new_disposition)

    ids = [_coerce_uuid(aid, "alert_ids") for aid in payload.alert_ids]
    try:
        rowcount = await apply_redisposition(
            db,
            tenant_id=user.tenant_id,
            alert_ids=ids,
            new_disposition=payload.new_disposition,
            analyst_id=user.user_id,
            confirmation_token=payload.confirmation_token,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    return RedispositionApplyResponse(updated=rowcount, new_disposition=payload.new_disposition)


class OverrideEntryModel(BaseModel):
    key: str
    tags: list[str]
    reason: str | None
    created_at: str | None
    value: dict


@router.get("/overrides", response_model=list[OverrideEntryModel])
async def list_overrides_endpoint(
    user: AuthUser,
    db: DBSession,
    limit: int = 100,
) -> list[OverrideEntryModel]:
    """List analyst-override entries the agent has 'learned' from."""
    rows = await list_overrides(db, tenant_id=user.tenant_id, limit=limit)
    return [OverrideEntryModel(**r) for r in rows]


class OverrideSummaryResponse(BaseModel):
    total_overrides: int
    false_positive_corrections: int
    true_positive_corrections: int
    # Counted separately from false_positive so a valid detection of authorized
    # activity never inflates the false-positive rate on the FPR card (#526).
    benign_true_positive_corrections: int = 0
    benign_corrections: int
    escalate_corrections: int


@router.get("/summary", response_model=OverrideSummaryResponse)
async def get_override_summary(
    user: AuthUser,
    db: DBSession,
) -> OverrideSummaryResponse:
    """Return a summary of analyst overrides for this tenant."""
    counts: dict[str, int] = {
        "true_positive": 0,
        "benign_true_positive": 0,
        "false_positive": 0,
        "benign": 0,
        "escalate": 0,
    }
    rows = await db.execute(
        select(Alert.disposition, func.count())
        .where(
            and_(
                Alert.tenant_id == user.tenant_id,
                Alert.disposition.isnot(None),
            )
        )
        .group_by(Alert.disposition)
    )
    total = 0
    for disp, cnt in rows.all():
        if disp in counts:
            counts[disp] = int(cnt or 0)
        total += int(cnt or 0)

    return OverrideSummaryResponse(
        total_overrides=total,
        false_positive_corrections=counts["false_positive"],
        true_positive_corrections=counts["true_positive"],
        benign_true_positive_corrections=counts["benign_true_positive"],
        benign_corrections=counts["benign"],
        escalate_corrections=counts["escalate"],
    )


class ContextStatementModel(BaseModel):
    statement: str
    reason_code: str
    scope: str
    scope_value: str
    observations: int
    expires_at: str | None = None


class ContextStatementsResponse(BaseModel):
    tenant_id: str
    statements: list[ContextStatementModel]


@router.get("/context-statements", response_model=ContextStatementsResponse)
async def get_context_statements(
    user: AuthUser,
    db: DBSession,
    tenant_id: uuid.UUID | None = None,
    x_aisoc_service_token: Annotated[str | None, Header()] = None,
) -> ContextStatementsResponse:
    """Unexpired organisation memory for a tenant.

    Uses the standard Bearer principal and ``alerts:read`` permission. The
    agents worker presents a tenant-scoped API key; an X-AiSOC-Service-Token
    header alone never authorizes this read. The legacy header parameter is
    retained for callers, but grants no authority.

    A session caller's ``tenant_id`` is **intersected** with the session rather
    than ignored. Ignoring it is safe but dishonest — a caller who names
    another tenant gets this tenant's memory back under that tenant's name,
    which is the "silently returns the wrong data" shape rather than a
    refusal. ``scoped_tenant_or_403`` returns the caller's own tenant when the
    parameter is absent, honours it when it matches, and 403s otherwise.
    """
    if user is None:  # Defensive for direct calls; HTTP resolves AuthUser first.
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Bearer authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )
    user.require_permission("alerts:read")
    scoped = scoped_tenant_or_403(user, tenant_id)
    await set_rls_context(db, scoped)
    rows = await active_statements(db, scoped)
    return ContextStatementsResponse(
        tenant_id=str(scoped),
        statements=[
            ContextStatementModel(
                statement=str(r["statement"]),
                reason_code=str(r["reason_code"]),
                scope=str(r["scope"]),
                scope_value=str(r["scope_value"] or ""),
                observations=int(r["observations"] or 0),
                expires_at=r["expires_at"].isoformat() if r.get("expires_at") else None,
            )
            for r in rows
        ],
    )


# ---------------------------------------------------------------------------
# Internal route: the last N analyst decisions, with a point-in-time cutoff
# ---------------------------------------------------------------------------


class RecentDispositionModel(BaseModel):
    """One analyst decision, with the part that generalises."""

    feedback_id: uuid.UUID
    analyst_disposition: str
    ai_disposition: str
    reason_code: str
    reason_label: str
    note: str
    scope: str
    scope_value: str
    rule_id: str | None
    decided_at: str
    created_at: str
    by_rule: bool
    by_entity: bool
    row_source_sha256: str


def _recent_disposition_model(row: Any, tenant_id: uuid.UUID) -> RecentDispositionModel:
    """Fingerprint this current API projection, not an old DB row version.

    The stable identity is feedback_id. This digest includes tenant, rendered
    reason label and query-dependent match flags, so it identifies the exact
    source projection provided by this request. The store has no update time
    or version history from which to reconstruct later-edited old notes.
    """
    timestamp = row.created_at.isoformat() if row.created_at else ""
    source = {
        "feedback_id": str(row.feedback_id),
        "analyst_disposition": str(row.analyst_disposition),
        "ai_disposition": str(row.ai_disposition),
        "reason_code": str(row.reason_code),
        "reason_label": REASON_CODES[row.reason_code].label if row.reason_code in REASON_CODES else str(row.reason_code),
        "note": str(row.note or ""), "scope": str(row.scope),
        "scope_value": str(row.scope_value or ""), "rule_id": str(row.rule_id) if row.rule_id else None,
        "created_at": timestamp, "decided_at": timestamp,
        "by_rule": bool(row.by_rule), "by_entity": bool(row.by_entity),
    }
    encoded = json.dumps({"tenant_id": str(tenant_id), **source}, sort_keys=True,
                         separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return RecentDispositionModel(**source, row_source_sha256=hashlib.sha256(encoded).hexdigest())


class RecentDispositionsResponse(BaseModel):
    tenant_id: str
    as_of: datetime | None
    dispositions: list[RecentDispositionModel]
    #: Matching decisions refused for post-dating the cutoff. Zero when no
    #: cutoff was asked for. Without it a cutoff that matched nothing and a
    #: cutoff that refused fifty decisions are the same empty list.
    excluded_after_cutoff: int
    #: Matching rows with no ``created_at``. The column is ``NOT NULL`` with a
    #: default so this should stay zero, and it is published anyway for the
    #: same reason ``statements_without_timestamp`` is.
    without_timestamp: int


#: Match a decision to this alert the two ways an author's decision
#: generalises. The rule is the stronger claim, so it comes first in the
#: ordering below; an entity match is the fallback that makes a decision about
#: one host or principal reachable from a different rule.
#:
#: ``{cutoff}`` and ``{excluded}`` are fixed literals, not caller data, and
#: they are the only thing that varies. See ``recent_dispositions_sql``.
_RECENT_DISPOSITIONS_SQL = """
WITH matches AS (
    SELECT id AS feedback_id, analyst_disposition, ai_disposition, reason_code, scope, scope_value,
           note, created_at, context ->> 'rule_id' AS rule_id,
           (context ->> 'rule_id' IS NOT NULL AND context ->> 'rule_id' = :rule_id) AS by_rule,
           (scope_value <> '' AND lower(scope_value) = ANY(CAST(:entities AS text[]))) AS by_entity
    FROM aisoc_analyst_feedback
    WHERE tenant_id = :tenant_id
      AND (
            (context ->> 'rule_id' IS NOT NULL AND context ->> 'rule_id' = :rule_id)
         OR (scope_value <> '' AND lower(scope_value) = ANY(CAST(:entities AS text[])))
      )
),
counted AS (
    SELECT
        count(*) FILTER (WHERE {excluded}) AS excluded_after_cutoff,
        count(*) FILTER (WHERE created_at IS NULL) AS without_timestamp
    FROM matches
)
SELECT c.excluded_after_cutoff, c.without_timestamp,
       m.analyst_disposition, m.ai_disposition, m.reason_code, m.scope,
       m.feedback_id, m.scope_value, m.note, m.created_at, m.rule_id, m.by_rule, m.by_entity
FROM counted c
LEFT JOIN LATERAL (
    SELECT * FROM matches
    {cutoff}
    ORDER BY by_rule DESC, created_at DESC, feedback_id
    LIMIT :limit
) m ON TRUE
"""


def recent_dispositions_sql(*, cutoff: bool) -> str:
    """The statement the route runs, with or without the point-in-time predicate.

    A function rather than two constants for the same reason
    ``knowledge_base.triage_retrieval_sql`` is one: the live-Postgres test has
    to run *this* statement, and a test that formats the template with its own
    idea of the cutoff clause keeps passing after the clause is deleted.
    """
    if not cutoff:
        return _RECENT_DISPOSITIONS_SQL.format(excluded="FALSE", cutoff="")
    return _RECENT_DISPOSITIONS_SQL.format(excluded="created_at > :as_of", cutoff="WHERE created_at <= :as_of")


@router.get(
    "/recent-dispositions",
    response_model=RecentDispositionsResponse,
    include_in_schema=False,
    summary="Recent analyst decisions for this rule or entity, as of a point in time",
)
async def recent_dispositions(
    user: AuthUser,
    db: DBSession,
    tenant_id: uuid.UUID | None = None,
    rule_id: str = "",
    entities: Annotated[list[str] | None, Query()] = None,
    as_of: datetime | None = None,
    limit: Annotated[int, Query(ge=1, le=20)] = 5,
    x_aisoc_service_token: Annotated[str | None, Header()] = None,
) -> RecentDispositionsResponse:
    """The last few times an analyst decided an alert of this shape, and why.

    Gap-closure Phase 6.3. Distinct from ``/context-statements`` next door,
    which serves *compiled* organisation memory: a statement needs two
    analysts agreeing on a reason before it is trusted, by design, so a
    disagreement that has been recorded once is invisible there. These are the
    raw decisions, including the ones that have not yet crossed corroboration,
    which is the signal an analyst reading the queue by hand would have.

    Feedback writes append rows, but the database does not enforce immutable
    text and has no update time/history. A creation-time cutoff cannot prove
    that a later-edited note had the same content at the split.

    A standard Bearer principal with ``alerts:read`` authorises the read.
    The optional tenant narrows the principal's scope and defaults to its own
    tenant; the retained shared X header grants no authority.

    ``as_of`` has no default. A default of "now" would let an unfrozen caller
    look frozen in a replay report; a default of the epoch would silently
    return nothing on every live triage.
    """
    if user is None:  # Defensive for direct calls; HTTP resolves AuthUser first.
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Bearer authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user.require_permission("alerts:read")
    scoped = scoped_tenant_or_403(user, tenant_id)
    await set_rls_context(db, scoped)

    params: dict[str, Any] = {
        "tenant_id": scoped,
        "rule_id": (rule_id or "").strip(),
        "entities": sorted({e.strip().lower() for e in (entities or []) if e and e.strip()}),
        "limit": limit,
    }
    if as_of is not None:
        params["as_of"] = as_of

    try:
        rows = (await db.execute(text(recent_dispositions_sql(cutoff=as_of is not None)).bindparams(**params))).fetchall()
    except Exception as exc:
        logger.warning("recent_dispositions.query_failed", error=str(exc)[:300])
        raise HTTPException(status_code=503, detail="Database error") from exc

    excluded = int(rows[0].excluded_after_cutoff) if rows else 0
    undated = int(rows[0].without_timestamp) if rows else 0
    return RecentDispositionsResponse(
        tenant_id=str(scoped),
        as_of=as_of,
        dispositions=[
            _recent_disposition_model(r, scoped)
            # The LATERAL yields one all-NULL row when nothing survives the
            # cutoff, which is the case the counts above exist to describe.
            for r in rows
            if r.analyst_disposition is not None
        ],
        excluded_after_cutoff=excluded,
        without_timestamp=undated,
    )
