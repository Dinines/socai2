"""Natural-language detection authoring endpoint.

Accepts a plain-English description of a threat and returns:
  - A Sigma YAML rule
  - Equivalent KQL (Microsoft Sentinel)
  - Equivalent SPL (Splunk)
  - Equivalent ES|QL (Elastic)

Uses an LLM (OpenAI-compatible) to perform the translation. Falls back to a
template-based stub when no LLM key is configured so the endpoint stays
functional in all deployment environments.
"""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime
from typing import Annotated, Any, Literal

import structlog
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from app.api.v1.deps import AuthUser, DBSession, require_permission
from app.core.airgap import AirgapViolation, enforce_airgap_for_url
from app.models.detection_proposal import DetectionRuleProposal
from app.services.detection_eval import evaluate_candidate_rule
from app.services.fixture_synth import derive_fixtures_from_sigma
from app.services.llm_safety import LLMContractViolation, safe_chat_completions_request
from app.services.model_aliases import (
    UnroutableModelError,
    chat_completions_url,
    resolve_api_key,
    resolve_model_alias,
)

logger = structlog.get_logger()

router = APIRouter(prefix="/nl-detection", tags=["nl_detection"])

_SEVERITY_MAP = {"informational": "info", "info": "info", "low": "low", "medium": "medium", "high": "high", "critical": "critical"}


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class NLDetectionRequest(BaseModel):
    description: str = Field(
        ...,
        description="Plain-English description of the threat behaviour to detect.",
        min_length=10,
        max_length=2000,
    )
    target_platforms: list[Literal["sigma", "kql", "spl", "esql"]] = Field(
        default=["sigma", "kql", "spl", "esql"],
        description="Which rule languages to generate.",
    )
    severity: Literal["informational", "low", "medium", "high", "critical"] = "medium"
    mitre_techniques: list[str] = Field(default_factory=list)


class NLDetectionResponse(BaseModel):
    description: str
    sigma: str | None = None
    kql: str | None = None
    spl: str | None = None
    esql: str | None = None
    model_used: str


# ---------------------------------------------------------------------------
# LLM translation helpers
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = """You are a detection engineering expert.
Given a plain-English threat description, generate detection rules in the
requested formats. Output ONLY valid rule content, no prose.

For Sigma: output valid YAML.
For KQL: output a valid Kusto query.
For SPL: output a valid Splunk search.
For ES|QL: output a valid Elastic ES|QL query.
"""

_TEMPLATE = {
    "sigma": """\
title: {title}
status: experimental
description: {description}
logsource:
  category: process_creation
  product: windows
detection:
  selection:
    CommandLine|contains: '<KEYWORD>'
  condition: selection
falsepositives:
  - Legitimate administration activity
level: {severity}
""",
    "kql": """\
// {title}
// {description}
SecurityEvent
| where EventID == 4688
| where CommandLine contains "<KEYWORD>"
| project TimeGenerated, Computer, Account, CommandLine
""",
    "spl": """\
// {title} — {description}
index=windows EventCode=4688
| where like(CommandLine, "%<KEYWORD>%")
| table _time, host, user, CommandLine
""",
    "esql": """\
// {title}
// {description}
FROM logs-*
| WHERE process.command_line LIKE "*<KEYWORD>*"
| KEEP @timestamp, host.name, user.name, process.command_line
""",
}


async def _llm_translate(request: NLDetectionRequest) -> dict[str, str | None]:
    """Attempt LLM-based translation; fall back to templates on any error."""
    # The detection builder asked ``OPENAI_MODEL`` for its model and posted to a
    # hardcoded api.openai.com — so it was the one LLM consumer that could not be
    # pointed anywhere, and the model it sent (`gpt-4-turbo-preview`, from
    # .env.example) is not one the bundled gateway defines. It is a
    # natural-language translation task, so it takes the `nl` role like every
    # other one.
    model = resolve_model_alias("nl")
    api_key = resolve_api_key(model) or ""
    if not api_key:
        logger.debug("nl_detection.llm_unavailable", reason="no API key resolved for the nl role")
        return _template_fallback(request)

    platforms_str = ", ".join(request.target_platforms)
    user_prompt = (
        f"Threat description: {request.description}\n\n"
        f"Severity: {request.severity}\n"
        f"MITRE techniques: {', '.join(request.mitre_techniques) or 'unknown'}\n\n"
        f"Generate detection rules for: {platforms_str}.\n"
        f"Return JSON with keys matching the platform names (sigma, kql, spl, esql)."
    )

    try:
        completions_url = chat_completions_url(model)
    except UnroutableModelError as exc:
        logger.warning("nl_detection.unroutable_model", model=model, reason=str(exc))
        return _template_fallback(request)
    try:
        enforce_airgap_for_url(completions_url)
    except AirgapViolation as exc:
        logger.info("nl_detection.airgap_block", url=completions_url, reason=str(exc))
        return _template_fallback(request)

    try:
        # T2.3 — the description is analyst-authored but routinely contains a
        # pasted log line, which is exactly what the contract refuses to
        # forward.
        body = await safe_chat_completions_request(
            api_key=api_key,
            model=model,
            messages=[
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            url=completions_url,
            timeout=30.0,
            response_format={"type": "json_object"},
            temperature=0.1,
            max_tokens=2000,
        )
        rules = json.loads(body["choices"][0]["message"]["content"])
        return {
            "sigma": rules.get("sigma") if "sigma" in request.target_platforms else None,
            "kql": rules.get("kql") if "kql" in request.target_platforms else None,
            "spl": rules.get("spl") if "spl" in request.target_platforms else None,
            "esql": rules.get("esql") if "esql" in request.target_platforms else None,
            "_model": model,
        }
    except LLMContractViolation as exc:
        logger.warning("nl_detection.llm_contract_violation", reason=exc.reason)
        return _template_fallback(request)
    except Exception as exc:
        logger.warning("nl_detection.llm_error", error=str(exc))
        return _template_fallback(request)


def _template_fallback(request: NLDetectionRequest) -> dict[str, str | None]:
    title = request.description[:60].replace("\n", " ").strip()
    ctx = {"title": title, "description": request.description, "severity": request.severity}
    return {
        "sigma": _TEMPLATE["sigma"].format(**ctx) if "sigma" in request.target_platforms else None,
        "kql": _TEMPLATE["kql"].format(**ctx) if "kql" in request.target_platforms else None,
        "spl": _TEMPLATE["spl"].format(**ctx) if "spl" in request.target_platforms else None,
        "esql": _TEMPLATE["esql"].format(**ctx) if "esql" in request.target_platforms else None,
        "_model": "template",
    }


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


# `/translate` drafts and `/propose` persists, so they take the read and the
# write of the same resource. `rules:read` rather than `rules:write` on the
# drafting half because nothing is stored: rule text in, rule text out. It is
# still a real refusal — `viewer` holds neither, and the roles that may author
# detection content are exactly the roles that may draft it.
@router.post("/translate", response_model=NLDetectionResponse)
async def translate_detection(
    payload: NLDetectionRequest, user: Annotated[AuthUser, Depends(require_permission("rules:read"))]
) -> NLDetectionResponse:
    """Convert a plain-English threat description into multi-platform detection rules."""
    if not payload.description.strip():
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="description must not be empty",
        )

    rules = await _llm_translate(payload)
    model_used = rules.pop("_model", "unknown")

    logger.info(
        "nl_detection.translate",
        platforms=payload.target_platforms,
        model=model_used,
        description_len=len(payload.description),
    )

    return NLDetectionResponse(
        description=payload.description,
        sigma=rules.get("sigma"),
        kql=rules.get("kql"),
        spl=rules.get("spl"),
        esql=rules.get("esql"),
        model_used=model_used,
    )


class NLProposeRequest(BaseModel):
    description: str = Field(..., min_length=10, max_length=2000)
    severity: Literal["informational", "low", "medium", "high", "critical"] = "medium"
    mitre_techniques: list[str] = Field(default_factory=list)


class NLProposeResponse(BaseModel):
    proposal_id: uuid.UUID | None
    status: str
    passed: bool
    reason: str
    sigma: str
    fixtures: dict[str, Any]
    model_used: str


@router.post("/propose", response_model=NLProposeResponse)
async def propose_from_nl(
    payload: NLProposeRequest,
    current_user: Annotated[AuthUser, Depends(require_permission("rules:write"))],
    db: DBSession,
) -> NLProposeResponse:
    """AI Detection Builder (W3.2): NL threat description -> Sigma rule +
    AUTO-GENERATED positive/negative fixtures -> non-circular eval-gate ->
    governed DRAFT proposal.

    Fixtures are DERIVED from the generated rule's own selection (not invented
    by the LLM), so the gate genuinely proves the rule fires on a positive and
    stays quiet on a negative. If the rule can't be auto-verified, no proposal
    is opened and the human is asked to supply fixtures — the honest outcome."""
    translate_req = NLDetectionRequest(
        description=payload.description,
        target_platforms=["sigma"],
        severity=payload.severity,
        mitre_techniques=payload.mitre_techniques,
    )
    rules = await _llm_translate(translate_req)
    model_used = rules.pop("_model", "unknown")
    sigma = rules.get("sigma") or ""
    if not sigma.strip():
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="could not generate a Sigma rule")

    derived = derive_fixtures_from_sigma(sigma)
    if derived is None:
        return NLProposeResponse(
            proposal_id=None,
            status="needs_fixtures",
            passed=False,
            reason=(
                "Could not auto-derive fixtures from the generated rule; supply "
                "positive/negative fixtures via /detection-proposals/{id}/evaluate-rule."
            ),
            sigma=sigma,
            fixtures={"positive": [], "negative": []},
            model_used=model_used,
        )
    positive, negative = derived
    result = evaluate_candidate_rule(rule_language="sigma", rule_body=sigma, positive_fixtures=positive, negative_fixtures=negative)

    proposal = DetectionRuleProposal(
        tenant_id=current_user.tenant_id,
        name=f"AI: {payload.description[:60].strip()}",
        description=payload.description,
        rule_language="sigma",
        rule_body=sigma,
        category="ai-generated",
        severity=_SEVERITY_MAP.get(payload.severity, "medium"),
        confidence=60,
        mitre_techniques=payload.mitre_techniques,
        status="eval_passed" if result.passed else "draft",
        eval_result={
            "candidate_rule": {
                **result.to_dict(),
                "auto_generated_fixtures": True,
                "fixtures": {"positive": positive, "negative": negative},
                "ran_at": datetime.now(UTC).isoformat(),
            }
        },
        proposed_by_id=current_user.user_id,
    )
    db.add(proposal)
    await db.commit()
    await db.refresh(proposal)

    logger.info("nl_detection.proposed", proposal_id=str(proposal.id), passed=result.passed, model=model_used)
    return NLProposeResponse(
        proposal_id=proposal.id,
        status=proposal.status,
        passed=result.passed,
        reason=result.to_dict().get("reason", ""),
        sigma=sigma,
        fixtures={"positive": positive, "negative": negative},
        model_used=model_used,
    )
