# 调查模块入口

当前状态见 [PROGRESS](../../PROGRESS.md)，前后端接手以[交接指南](../../FRONTEND_BACKEND_HANDOFF.md)为准。21核心已发布固定A/I→Case功能版`v1.2-20261113-r1`；当前[程序流程与输入输出](model-input-output-current-20261109.md)、[实际请求](../operations/evidence/fixed-investigation-20261113-10/README.md)和[发布回执](../operations/evidence/fixed-investigation-release-20261113-01/README.md)分别说明行为、证据和部署。独立HTTP两端已同步investigation-sync-20261113-r1及本机-local，Swagger docs19；最终回执以PROGRESS为准。

| 接手内容 | 资料 |
| --- | --- |
| 当前调查表范围 | [28 表职责／25 表有写入路径](investigation-table-scope.md)、[当前机器字典](../design/socai2-data-contract-current.json)；外部资产等基础数据由业务后端实现 |
| 页面功能与规则 | [逐页功能清单](../../deliverables/investigation-validation-20261106/frontend-feature-list.md)、[规则确认记录](../design/investigation-product-decisions.md)、[产品需求](../design/alert-incident-case-product-requirements.md) |
| 页面字段和跳转 | [F 字段分组／J 跳转附录](../../deliverables/investigation-validation-20261106/frontend-data-navigation-contract.md) |
| HTTP对接主入口 | [125项功能对应接口、输入输出与错误](../../deliverables/investigation-validation-20261106/http-handoff/README.md)；[本机/21 Swagger](../../deploy/api-docs/README.md) |
| 对外与内部接口 | [查询/业务操作与内部调用的边界](../design/investigation-http-boundary.md)；独立HTTP现有71操作，69实现/2问答暂缓；新版核心已同步两端investigation-sync-r1，原合同保持 |
| 数据及接口 | [数据交接](socai2-page-data-handoff-20261106.md)、[字段字典](../design/socai2-field-dictionary-20261103.md)、[OpenAPI](../design/socai2-independent-api-v2.openapi.json) |
| 程序及模型职责 | [执行账本](current-execution-ledger.md)、[模型输入输出](model-input-output-current-20261109.md) |
| 问题与后续验收 | [问题清单](current-issues.md)、[OpenSpec 任务](../../openspec/changes/complete-socai2-investigation-chain/tasks.md) |
| 采用结果与未完任务 | [采用规则AD01–AD06](result-adoption-and-pending-work.md)及[调用指南](../integration/result-adoption-http.md)；E21/E63/E64已交付，采用不等同任务完成或结案 |
| 实际实现审查 | [11-14当前功能与整体流程评审](investigation-current-review-20261114.md)：4177三案、生成/接收合同、取证效果、队列与更新、状态及入口；[11-11独立审查](investigation-flow-review-20261111.md)保留历史适用范围 |
| 当前交付与下一项 | Case/H、分诊后知识同步、Case管理及告警/事件管理已交付；[HTTP分离](../../openspec/changes/archive/2026-11-13-separate-investigation-http/validation.md)已独审归档。[三类列表查询](../../openspec/changes/archive/2026-11-13-query-investigation-lists/design.md)已完成本机/21及Swagger docs8发布、独审归档；完整CSV导出及E57归并统计也已发布，普通评论E58/E59也已发布，附件引用E60–E62已发布，文件上传/下载由业务后端负责；Swagger实际版本以根交接指南为准；采用预览/提交/判断历史已交付；[案件故事E65](../integration/case-story-http.md)已发布并读回；[E66案件候选](../integration/case-exploration-http.md)已发布两端并读回，保存恢复E67–E69已交付；各页面AI对话按负责人要求暂缓，告警分诊/事件诊断/Case调查保持原计划，其他接口按[计划](http-implementation-plan-20261112.md)推进。固定调查和模型质量进展见[PROGRESS](../../PROGRESS.md) |
| 21 与本机接入 | [部署](../../deploy/aisoc21/README.md)、[SSH 转发](../operations/mac-ssh-relay-20261107.md) |
| 资料归档与保留 | [历史索引](../handoff/history/README.md)、[代码与数据保留清单](../handoff/retention-map.md) |
| 运行原件及样例 | [工作台与离线材料](../../deliverables/investigation-validation-20261106/README.md)、[最新固定Run](../operations/evidence/fixed-investigation-20261113-10/README.md) |

原始需求、各批失败及模型原答均保留。实现、运行交付、数据读取、页面接线和模型质量分别验收；未完成主任务继续保留在主调查 OpenSpec；各独立交付按一个 change 完整验收后发布。

按目标知识的执行位置、字段/索引/配置与 4177 展示见 [Case 知识交接](case-knowledge-handoff.md)。

- [历史告警知识与模型交接](historical-alert-knowledge-handoff.md)：显式卡片入库、C2 历史目标、模型角色与 4177，交付状态以 PROGRESS 为准。
- [知识检索与入库设计](../../openspec/changes/archive/2026-11-12-refine-purpose-aware-knowledge-use/design.md)：用途筛选、按阶段提供去重内容及历史选入／修订时机；一次直接流程及独审后已发布 21 r3，写读与 4177 回执见验收，模型质量保持 NOT_PASSED。

- [分诊保存后同步历史知识](../../openspec/changes/archive/2026-11-12-sync-saved-alert-knowledge/proposal.md)：已完成本地直接流程、独审及 21 r5 加载读回；新 A 分诊提交并采用后按配置维护卡片／索引，不启用全链消费者，人工反馈保持显式入口。

[探索保存恢复 E67–E69](../integration/case-exploration-save-http.md)：读取底图、保存固定展开/画布、恢复最近保存；不产生调查或改变成员。

[E70告警相似历史复核](../integration/alert-review-http.md)：读取匹配来源及原判定，人工确认后再反馈。

[告警同主机最近7条E71](../integration/alert-host-http.md)：匹配规则、输入输出、原件回查及错误。
