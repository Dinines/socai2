# 调查流程与交接问题清单

更新于 2026-11-14。当前发布和字段合同见[交接指南](../../FRONTEND_BACKEND_HANDOFF.md)。下列未完项独立于部署、读取和字段对应验收；登记不代表修复或取消需求。历史[独立流程审查](investigation-flow-review-20261111.md)保留当时结论，不能将其中已修复/已交付事项继续算作当前缺口。

本轮[当前功能与整体流程评审](investigation-current-review-20261114.md)按4177三案原件、当前代码和21只读状态登记RV01–RV13，逐项说明影响、优先级及直接验收。它不替代主change结束审计，不修改既有质量后置决定。

## 本轮评审补充

| 评审项 | 新核实的内容 | 处理落点 |
| --- | --- | --- |
| RV01 生成与接收约束 | 登录A、C02/C03 C6三份已拒收原答均通过实际发送的Schema；重复引用及answered无依据未被生成约束阻止 | 主调查3.10/3.23/3.30内评估程序合同一致性，不能全部归入正文质量后置；旧原答/拒收保持 |
| RV02 C3输出截断 | C02在4096输出tokens处截断于followups，未形成有效C3及补查计划 | 评估必要输出结构、重复字段和预算，未实施修复、不扩大预算或重派旧Run |
| RV04 Deep实际取证 | 三案测试明确关闭ClickHouse和产品主机源；4次Deep无候选，0个C4.query | 属本批取证验收边界，不能认定生产工具故障；核补查目标与可用能力对应 |
| RV11 新材料入口 | 流式计划包含同告警新材料，生产重投/投影当前恢复首次快照 | 在流式2.2明确合法版本更新来源及接线；不能把同ID重投当更新接口 |
| RV12 4177结论展示 | 告警/事件“本轮交付”指向Run，正常`stage_output_saved`被归入错误；同Run的分诊判断/理由和事件诊断结论实际已保存 | P1，已定位未修复；先按同Run结果显示业务结论，结束原因另列。复用成功A/I及失败A验收，无需新模型或等待流式实施；[证据](../operations/evidence/investigation-current-review-20261114-01/workbench-conclusion-review.json) |
| RV13 入站运行及配置 | 21投影本轮三分区lag均0，Agents自动分析仍关闭；投影异常会held并退出实例 | 继续区分入站/调度/执行/交付/采用；停位与局部硬编码在触及路径内处理，不开展恢复专项 |

[离线证据及脚本](../operations/evidence/investigation-current-review-20261114-01/README.md)保留本轮取数修正记录。RV03/RV05复用M01/M02/F01/F02；RV06–RV10复用下表现有流式缺口，不另建任务树。以下已交付功能保持，CLI和本轮评审不核销主31/41。

## 当前功能缺口与实施入口

固定调查核心 `v1.2-20261113-r1`、独立 API `investigation-sync-20261113-r1` 和 Swagger docs19 已发布并读回。A/I/C3/Deep/C6 输入筛选、综合结论装配及保存读取已完成本阶段程序验收；H 版本保存、告警人工判定、Case 重开及结果人工采用均已交付。当前 71 个 HTTP 操作中 69 已实现、2 个 AI 对话暂缓 501，不能再把 HTTP 同步、反馈写入口或重开入口列为待补功能。证据见[固定发布](../operations/evidence/fixed-investigation-release-20261113-01/README.md)和[HTTP 同步](../operations/evidence/investigation-http-sync-20261113-01/README.md)。

| 当前实际缺口 | 代码/行为依据 | 后续实施落点 |
| --- | --- | --- |
| A/I 不同 operation key 可启动同一主体的多轮执行；Case 保护未与自动调度接通 | stage_results.begin 只按 key 幂等；baseline_store 已有 Case 单活跃和 pending，不能另建一套绕过它 | 先做同主体统一领取、执行容量及一运行/一 pending；[流式任务 2.1/2.3](../../openspec/changes/schedule-streaming-investigation-updates/tasks.md) |
| 新材料/成员/采用 A/告警人工判定未统一驱动 I 和 Case 更新 | 入站保存、stage_results.finish、subject_management 尚无统一持久化触发；目前显式请求执行 | 业务与待办同事务，按实际变化合并；新 A 只处理自己，I/Case 按窗口更新；2.2/2.3 |
| Case 关联事件后不跟随后续成员，人工排除也无持续跟随规则 | case_relations.incident_selection 只取关联当时成员 | 整个事件跟随后续新增，单告警不隐式跟随；人工移出不加回、旧关联不补扫、结案不自动重开；2.2 |
| H 能影响新鲜度，但不能自动只重算 C6 | human_task_service 保存版本；baseline_executor 默认仍走 C1–C6 | 以当前采用调查的必要原证据复核，仅 H 走 C6；新材料/告警反馈混入走 full，无基线提示需完整调查；2.4/2.5 |
| 分诊完成仍等待历史知识同步，且没有队列进度合同 | knowledge_sync.after_triage 在业务提交后等待；原回执可读但无统一调度状态 | 沿原知识资格与维护回执移入低优先级待办，新增受理/状态读取，保持原正文 GET；2.6/2.7 |
| 自动 A/I/Case 的真实接续未交付 | 当前 Agents 分析消费者关闭；Fusion/投影运行不证明模型自动执行 | 复用当前核心接统一 worker，直接验证入站→待办→执行→保存读取；不直接恢复旧 Agents，不自动建 Case；2.3/3.1 |

以上在已有 [schedule-streaming-investigation-updates](../../openspec/changes/schedule-streaming-investigation-updates/proposal.md) 内按四步实施，不新建任务树。流式规划批只更新计划，没有实施代码或迁移；11-14另按负责人要求完成三案固定流程展示测试，不属于流式实施。未来会增加内部待办/跟随/排除结构及独立状态接口，原告警交接字段、E13/E36/E37 同步语义保持。

**主调查 31/41 不等于还缺十个固定流程功能。** 3.7/3.10/3.14/3.16/3.23/3.30 含正文质量及未验业务范围；3.21 为自动接续，3.12 含产品操作与暂缓范围；4.1/4.2 是整体结束审计及归档。模型质量继续后置；Q 对话、真实响应和产品页面接线不作为本次调度前置。旧可选 C3.reanalysis 不在默认链路，需另按任务目标适配后才启用。

## 已决定后置的质量及历史证据

[11-14三案展示](../operations/evidence/fixed-investigation-20261114-01/README.md)新增4A/2I/3Case、19次生成，每个Run仅一次并沿现有有界纠正。E01登录A重复引用拒收；C01结论待复核且已采用，但仍有凭名称推自动化等正文问题；C02 C3达到4096输出上限截断，C6两答缺依据并有范围错配；C03 C6两答建议重复引用。后两案结论null、未采用，原答/失败及NOT_PASSED保持。C3输出长度/结构留待后续评估，本批不重派。4177和4173已同步真实保存结果与空态，未核销产品完整接线或质量项。

负责人2026-11-13再次明确“质量问题可以后续解决”。M01/M02、F01的反馈合理利用、F02的知识合理利用等模型正文质量项统一后置，不阻塞已验证的固定流程功能收口和新版发布；不再为它们追加模型采样。原答、失败及NOT_PASSED保持，不改成已修复。保存/读取错误、来源或成员串案、合同破坏等程序功能阻断仍需修复，不能归为正文质量后置。此前[后置决定](../../openspec/changes/archive/2026-11-11-ground-case-conclusions/scope-decision.md)与旧证据保留。

前期固定输入曾有明确的材料选择缺口；以下保留各批当时状态，相关程序修改现已随上述功能版发布，旧 Run 和失败不追认修复：原始日志很小，历史和执行台账却层层累积，04批C6在63,262字符超限前未派发。按负责人要求，先定义模型目标、禁止原始结构整包透传；[字段梳理](../../openspec/changes/complete-socai2-investigation-chain/model-input-field-review-20261112.md)已完成，查询只给结果及 A/I/C3 字段筛选已本地修改并离线核验；I 当前3,047字符，原冻结 C3 仍7,680字符，成员归属/原文/原引用保持。C3 的有效 I 整体结论引用保留遗漏已按独审补齐并定向复验。完整 JSON 的新导入切片及 C3/Deep/C6 已识别知识正文投影已本地修复，[新导入离线预览](../operations/evidence/model-input-selection-20261112-05/README.md)6,930字符；没有实际导入、索引或模型调用，旧两段仍保留，不能当旧 Run 已修复。未知结构保持；[Deep/C6 整理](../operations/evidence/model-input-selection-20261112-06/README.md)已本地按指定问题/全案结论筛选，正文8,768/14,080字符，必要前序支持/反证保持。旧知识切片仍在本批冻结输入中，未手工拼接；离线重建不代表真实 C6 超限或模型质量已经通过。HTTP 字段/数据库表不变，不手工拼文档；输入变短不证明M01/F02已修复，不继续采样追求通过。

前批[固定05批](../operations/evidence/fixed-investigation-20261112-05/README.md)已实际导入/索引完整AN0846，C2两用途返回并合并一份正文进入C3/Deep/C6；行为性质问题的知识引用保存GET一致。C6正文18,563字符未再超限，但两次建议均重复N6_S9，拒收符合原答；C3仍错误使用案件外历史目录。I虽通过引用校验，仍忽略已给登录事实；模型凭名称推自动化流程的问题保留。Result rejected/partial/null且未采用，F02/M01/M02不核销。随后[离线修正](../operations/evidence/case-citation-input-20261113-01/README.md)按条筛历史并明确案件外范围；被I明确引用的N3_S238仍保留，只移除2条无依赖目录。局部纠错给字段原值、重复号和错配主体，C3/C6反馈949/467字符；原答仍拒收，70份旧文件不变。3项已有检查及限定独审通过，零新模型/数据库调用，实际纠错效果仍未验；不以缩短输入追认质量。

[固定06批三例对照](../operations/evidence/fixed-investigation-20261113-06/comparison.md)完成13次真实模型调用，均rejected/unavailable/partial且未采用。H01/H02人工原文/范围进入模型并被归因，H02未扩成全案授权；其模拟声明不能证明正常有效授权采纳。三例仍凭名称推自动化，H02正文夸大为完整行为链，M01/M02保持NOT_PASSED并停止采样。H01不可用基线却回答unchanged，生成/诊断缺口已离线修正；原拒收及当前判断为空保持，新提示真实效果未验。全部请求/原答/失败及读取快照可重放。三例知识嵌入均503，正常知识参与本批未验；预算未耗尽，不扩大预算。

06批的C3观察装配容量缺口已由[本轮程序修复](../operations/evidence/case-observation-input-20261113-01/README.md)处理：同记录/字段/同值共享展示，27来源及原值不变，1822→984；B01第2答仅新v2离线预览通过，旧v1拒收和真实Run保持。C6四份影响段缺成员依据仍拒收，当时仅离线聚焦字段/主张/候选，真实纠错效果另见07批。5项直接检查及一条隔离库替身保存读取通过不构成模型质量通过；不以连续采样处理已登记正文问题。

前批[固定07批](../operations/evidence/fixed-investigation-20261113-07/README.md)只新增一轮：原H01/A/I复用，正常知识448字符进入实际C3/C6，3次生成、41,320tokens。C6一次局部反馈后收窄影响成员，accepted/uncertain/partial并保存/GET一致；原首答拒收保持。这证明本次纠错及存取生效，不证明稳定质量；知识未被结构化引用、名称推自动化及未查写查空仍存在，不继续采样。不可比却写与历史一致的职责缺口已改为[新请求固定装配](../operations/evidence/case-fixed-comparison-20261113-01/README.md)，4项直接检查及1条隔离库替身存取通过，旧原答/采用记录不回写。该批当时模型修改尚未部署，现已随核心及独立 HTTP 功能版发布；F01/F02/M01整体仍未通过。

[按任务选择C3/C6输入](../operations/evidence/case-task-input-20261113-01/README.md)的离线实现已通过限定核验；随后[08批真实两例](../operations/evidence/fixed-investigation-20261113-08/README.md)实际使用各自新C3有效片段进入C6。B01接受待复核并采用；H01最终拒收且当前判断未覆盖，保留的B01已标为stale/human_feedback_changed。H回应了不同来源IP、启动/完成及反馈非授权等边界，名称推自动化仍存在；B01 C3/C6、H01 C3引用知识，但F01/F02/M01仍NOT_PASSED。9次生成后停止采样，预算未增加，原答与失败保持。

H01暴露实际程序缺口：N5_S87同文历史背景与N5_S94指定基线共用显示，接收只认后者，且首份纠错漏报指定基线缺失。按[第24节](../../openspec/changes/complete-socai2-investigation-chain/model-input-field-review-20261112.md#24-指定比较引用与同文背景短号的职责区分)已明确输入职责及v9字段反馈；原记录/严格接收保持，两项直接检查及实际原答离线核对通过，不把H01拒收改成通过。随后[09批](../operations/evidence/fixed-investigation-20261113-09/README.md)一次新Run/4次生成，C6首答引用指定基线，v9一次重复引用纠错后accepted/uncertain/partial并采用，新鲜度current。实际未出现同文背景别名或缺基线诊断，这些分支仍只有离线证据；4次ASGI与保存一致，137份08文件保持。比较正文仍无依据地宣称本轮更充分，质量NOT_PASSED，不再采样。随后[第25节离线修复](../operations/evidence/case-deep-knowledge-20261113-01/README.md)为授权Deep增加配置化问题用途限制，不默认追加可选知识，必要前序依赖仍恢复。09实际输入重建11,921→11,235字符，105条其他记录/26依赖和55份原件保持；1项直接检查通过，0新模型/数据库调用。只解决本问题的可选知识选入，不代表F02合理使用通过。随后[第26节C6修复](../operations/evidence/case-final-knowledge-20261113-01/README.md)保留问题/用途/成员配对，避免跨问题拼接；授权单问题不选可选卡，有其他匹配问题或前序依赖仍保留。1项直接检查通过，09完整C6请求仍13,526字符/105记录/52依赖、有用知识保留，82份旧件不变；无新模型/数据库调用、未重验正文效果，其他正文错误继续后置，流式不前移。

## 待完成事项

| 编号 | 问题及影响 | 当前处理与验收落点 |
| --- | --- | --- |
| M01 | 模型扩大正文事实，结构合法不保证主张有据 | 质量 NOT_PASSED。程序覆盖和观察原值装配已直接验证；第五批命令结果边界改善；Deep 仍凭 synthetic 标签断言非生产环境，C6 替代解释将四项未查询也说成查空，两项已保存读回。另有时间间隔计算错误；固定 coverage 正确不代表其他正文正确；见[当前验收](../../openspec/changes/archive/2026-11-11-ground-case-conclusions/validation.md) |
| M01-A | 模型将 synthetic 等来源标签推成业务环境/良恶性事实 | **已知、后置，未修复**。第五批 Deep 原答及保存 GET 可复现；只应据对应业务材料或明确归属的人工陈述判断环境。按负责人决定不阻塞发布/后续功能，原质量结论保持；[10批](../operations/evidence/fixed-investigation-20261113-10/quality.json)仍从名称/标签推自动化特征，按原决定保留正文质量未通过、不追加采样 |
| M01-B | 模型自由正文将未查询写成查空 | **已知、后置，未修复**。第五批 C6 F1 替代解释与程序 coverage 的 2 查空/4 未查矛盾；原字段/原答保留，真实状态以程序回执为据。07批再次出现未查询威胁情报写成无结果，原答保持，按已确认决定不重复采样 |
| M02 | 角色引用合规与正文有据需分开持续验收 | 当前NOT_PASSED。历史各次拒收/接受及回执保留；[07批](../operations/evidence/fixed-investigation-20261113-07/README.md)一次C6局部反馈后将影响范围从A1/A2/A3收窄为A1/A3，支持引用不变，结构及引用接受并落库。但名称推自动化、未查写查空、错误比较说明仍在，接受不代表主张真实或稳定；比较固定装配的程序修复见F07 |
| F01 | H 后再次调查的传递已验证，正确利用反馈及有据结论仍未通过 | 本轮真实 HTTP 的第 2 修订进入后轮冻结及 4 份实际请求 body，后轮承认人工不是业务授权、命令结果未知；只证明本批部分利用，完整语义质量未通过。07批进一步复用H01得到accepted/uncertain/partial并保存读回，但完整语义质量仍未通过。前批修订及错误原答保留，不核销3.7 |
| F02 | 知识传递已验证，召回相关性及合理使用效果未通过 | 历史知识本地 C2 9 查询/10 行，历史卡 2 命中/1 唯一卡，5 份请求可见原分诊/人工正文及独立角色；结构化引用数组未引用历史，部分正文有提及，登录主题也命中进程卡，合理使用未证明。技术解释/方法前批证据保留；生产实际接线见根 PROGRESS。graph、自动消费和方法推动取证仍未验。[知识筛选改进](../../openspec/changes/archive/2026-11-12-refine-purpose-aware-knowledge-use/tasks.md)已实施并发布 21 r3；新批次 9 查询／5 行（3 唯一块），排除 6 次条件冲突和 2 次过期卡候选，合并 2 次跨目的正文。6 模型后 C6 仍拒收；被接受结果未结构化引用知识，合理使用质量仍未通过，不核销本项。[历史知识验收](../../openspec/changes/archive/2026-11-12-use-historical-alert-knowledge/validation.md) 本地固定流程进一步修正辅助知识范围/覆盖与同出处选取，已有历史引用保存读回；C6 建议空引用拒收，Schema 随后补齐，不追认原答。07批正常检索并向三个实际请求各提供一张448字符卡，原答未结构化引用知识，合理使用仍未证明。见[本批验证](../../openspec/changes/complete-socai2-investigation-chain/fixed-flow-validation-20261112.md)。 |
| O01 | 自动消费者暂停；恢复后的实际消费、自动分诊和建案未验收 | 本批不启动消费者；按已有服务范围单独核验，健康探针不证明处理成功 |
| W01 | Case/H 产品页面操作仍需接线验收 | 本地 13 次原 HTTP 请求及后轮版本/结果比对通过；21 r2 写入口已开放，正常登录后 8 次业务请求及任务字段匹配通过。服务端范围见 R08，产品页面操作仍未验收，不用 4177 代替 |
| P01 | 事件概览缺本次诊断入口 | 对应 J04；由成员主体及 Run UUID 打开实际诊断尝试，失败也可查 |
| P02 | 原页面 `severity_effective=medium` 显示错误 | 对应 F06；应显示“中”，保留来源为人工覆盖或成员最高值 |
| P03 | 原运行页把 `delivery_state=none` 与字段缺失混为一类 | 对应 F15；已记录 none 显示未交付，缺失按未知处理 |
| P04 | 无效告警 ID 缺明确未找到及返回入口 | 对应 J01；404 应终止下钻并允许返回 |
| P05 | 真实响应等仍有缺口；同主机近期展示E71已交付；普通案件故事E65、案件候选E66和探索保存E67–E69和相似历史复核E70已交付；文件上传/下载由业务后端负责 | 普通评论E58/E59已交付；[附件引用E60–E62](../../openspec/changes/archive/2026-11-13-link-case-attachments/validation.md)已完成F24-02/03中本服务负责的关联登记/目录/单项，业务后端文件链路未据此验收。F20非对话读取由E65完成，AI对话暂缓；E66完成F25候选查询及明确加入衔接，F25保存恢复已完成本服务HTTP能力；F27真实响应仍未完成；响应只以真实审批／动作／回执为据 |
| Q01 | 各页面AI对话暂缓（未实现） | 2026-11-13负责人明确暂缓助手入口、提问/追问、会话历史、回答读取及保存；E19/E20仍返回501。告警分诊、事件诊断、Case调查按原计划推进；E21只采用符合资格的既有基础调查结果，已交付状态保持 |
| Q02 | 人工采用核心与HTTP已交付；流式/自动反馈重算仍后置 | E63预览、E21采用、E64历史复用[AD01–AD06](result-adoption-and-pending-work.md)，本机20HTTP/SQL和21已有数据只读通过；[发布证据](../../openspec/changes/archive/2026-11-13-adopt-investigation-results/validation.md)。采用不结束任务、Run或案件；0模型、无迁移。21未做生产采用写验收；并发矩阵和流式不在本批范围 |

四项 P01–P04 是已保存的产品页面核对结论；4177 内部工作台的节点详情优化不核销这些产品页面事项。[功能与跳转清单](../../deliverables/investigation-validation-20261106/frontend-feature-list.md) · [原始页面证据](investigation-test-handoff-20261106.md#下一阶段的前后端交接验收)

审计基线、各批原答、校验、采用和读回关系分别保留。第五批执行 completed/交付 partial、C6 uncertain/accepted 并采用，不等于正文已经核实：原正文独审为 REVISE；负责人后置决定后的程序交付补充审查为 ACCEPT。第四批 rejected 原件保持，不改写采用/失败历史。

## 保留模块启用前的问题

以下属于 `services/agents` 的 Hunt，不是当前 `socai2` A/I/C/H 的执行链；生产暴露和真实多租户数据未在本轮验证。按该模块启用范围处理，不单开主线权限专项。

| 编号 | 问题及影响 | 修复与验收 |
| --- | --- | --- |
| A03 | Hunt 路由只执行认证，不消费 principal 的租户，读取与手动调度落到 default | 隔离真实 ASGI 复现两租户均用 default；从认证结果显式绑定目标并传入读写/执行，不能缺失回退；验收两个租户的下游目标匹配 |
| A04 | Hunt 数据湖失败变空列表，返回 ok=true，生成 completed/零行/error=null 的落库参数 | 隔离真实 loader→scheduler→engine→store 复现；保留采集失败/错误到接口和 Run，用正常零行与超时各一例直接验收 |

详细行号、触发、证据及限制见[独立流程审查](investigation-flow-review-20261111.md)。Swarm/Debate 的确定性评分与模拟 token 未证实接入目标路径，按保留模块说明，不认定主线模拟冒充真实。

## 已修正并复验

| 编号 | 发现与修正 | 证据 |
| --- | --- | --- |
| K01 | 新分诊保存后未接知识维护 | [分诊后同步](../../openspec/changes/archive/2026-11-12-sync-saved-alert-knowledge/validation.md)已完成本地 finish→索引→检索→GET、独审及 r5 实际加载，原判断／同步回执分开；生产无新增 Run。人工反馈自动触发和历史回填未纳入，消费者保持关闭 |
| K02 | 固定06批知识503保留；新批正常查询已通过 | 原三Run集合GET200/嵌入POST503及旧诊断不变。[新批复核](../operations/evidence/knowledge-retrieval-recovery-20261113-01/README.md)发现当前本机转发缺失；按原配置临时转发后一次嵌入和9条查询成功，两个用途返回同一知识，现有程序在C3/Deep/C6各选448字符正文。当前缺转发不能倒推旧503根因；临时转发已关闭，后续Run须保持对应连接。该查询批无生成调用/写库；后续07批在整个Run保持连接，正常检索并进入实际请求，但原答未结构化引用知识，F02继续未通过 |
| R08 | Case/H HTTP 共用只读连接，正常写入未接通 | 本轮显式写连接及来源配置已上线 r2，原 GET 保持；本地正常两轮/H 修订传递与生产正常登录写读通过，无表列或告警字段变更。[交付回执](../operations/evidence/case-human-http-20261111-01/delivery-summary.json)；产品页面仍列 W01 |
| A02 | C3 提示最多两项补查，但生成/接收曾允许 12 项 | 当前冻结配置、生成/接收/partial 均限 2，三项明确拒收且零派发，历史读取和 C6 建议兼容；直接检查通过，21 r1 实际加载上限 2，发布读回通过。[本次交付](../operations/evidence/case-grounding-20261111-01/delivery-summary.json)。原审计反例保持 |
| R01 | Case/H GET 共用关闭的写开关而 503；GET 现在接受页面读取开关，写操作仍受原开关约束 | 当前两案 365 GET、16,820 检查；读取开关／租户／权限与写入拒绝定向测试 |
| R02 | 安装核验器拒绝已经人工授权的 `aisoc_app` schema USAGE | 改为核实获准 SELECT、无调查写权限及无管理权限；实际 verify 通过，未执行 GRANT 或 DDL |
| R03 | 对账脚本只在本 Case 计算相关告警，遗漏同租户跨 Case 的合法结果 | 从同一只读快照读取匹配对象及当前材料，按类型／命名空间／对象键核对关联，复验零偏差 |
| R04 | 交接文档仍显示未部署／缺权限，OpenAPI 缺来源工件、活动及事件交付字段 | 当前入口、字段与接口导出统一更新；整理前文档归档，原失败／unknown／模型原答保持 |
| R05 | Deep/C6 生成 Schema 允许接收校验禁止的执行回执结论引用 | Deep 支持／反证及 C6 结论／比较／影响／建议的枚举排除执行回执；C6 analysis 保留查询覆盖引用。20 项边界检查、5 份原答离线复验通过；真实生成效果列 M02 |
| R06 | 核验器假定当前判断非空、Case／活动仅属于单案 | 支持空判断并拒绝伪造判断；按同租户完整主体关系核 Case、活动及 `via_member_alert`，补 H 详情和全部修订逐值核对。16,820 检查及独立活动 1,083 检查通过 |
| R07 | 4177 点击节点只能跳到下方原件，Deep 无动作时缺实际失败模型入口；展示源码变化不能刷新已有缓存 | 左侧流程／右侧详情已接通提示词、输入输出、错误和原件；Deep 每次实际调用可选，冻结输入分类经独审修正。30 项定向测试、307 条记录逐值保持及浏览器宽窄屏核验通过。见[节点详情验收](../../openspec/changes/complete-socai2-investigation-chain/workbench-node-inspector-20261110.md) |
| F03 | 分别保留查询出处与历史行主体，修正 C02 A3 查询中 A1 记录的引用范围 | C3／Deep／C6、冻结依赖恢复及案件外／冲突身份直接检查通过，原路径／角色／正文保持；[本轮验收](../../openspec/changes/archive/2026-11-10-fix-case-evidence-scope-and-recovery/validation.md) |
| F04 | 来源可见性、成员覆盖、C6 本次 finding 及 conclusion／impact 覆盖可定位错误获得一次具体反馈 | PG 已验证纠正成功与仍错时部分保留，前批真实 C6 已发生一次纠正；unknown／截断不重派。本轮补角色诊断见 F06，剩余正文问题见 M01 |
| F05 | Deep handoff 生成允许空答复、网关分支丢公共必填项，与接收合同不一致 | 每个 action／Answer 分支展开完整结构与限制；真实第三轮 handoff／answer 均完整通过，前两轮原失败保留；[69 项直接检查](../operations/evidence/case-scope-recovery-20261110-01/final-contract-tests.xml) |
| F06 | C3/C6 Finding 生成与接收的角色约束不一致，有限反馈遗漏角色错误 | 已统一部署并核来源：完整状态分支限制直接观察、v2 反馈给角色与逐成员缺口；86 项检查、两项 PG 流程和一轮真实生成通过该范围，原接收兼容性及历史原件保持。[角色验收](../../openspec/changes/archive/2026-11-10-align-case-finding-evidence-roles/validation.md)；独审 ACCEPT，21 r6 生产读回通过 |
| F07 | 不可用历史的比较说明曾由模型生成，与程序已知事实冲突 | [固定装配修复](../operations/evidence/case-fixed-comparison-20261113-01/README.md)在新C6请求前冻结initial/not_comparable和固定说明，移除模型输出槽，装配后保存GET一致；可用指定历史仍由模型比较。4项直接检查及1条隔离库替身存取通过，旧无标记原答/Result不变。修复当时仅本地验证，现已随核心及独立 HTTP 功能版发布；未为该分支追加采样，不追认07批错误比较正文 |

本次 Case/H 结果见 [HTTP 功能验收](../../openspec/changes/archive/2026-11-11-enable-case-human-http-flow/validation.md)；前序结果见[程序功能验收](../../openspec/changes/archive/2026-11-11-ground-case-conclusions/validation.md)及[交付回执](../operations/evidence/case-grounding-20261111-01/delivery-summary.json)。r6 参照批次见[角色验收](../../openspec/changes/archive/2026-11-10-align-case-finding-evidence-roles/validation.md)与[逐调用汇总](../operations/evidence/case-evidence-roles-20261110-01/execution-summary.json)。前批来源范围及纠正修复见[验收报告](../../openspec/changes/archive/2026-11-10-fix-case-evidence-scope-and-recovery/validation.md)；原[Case 流程实测](../../openspec/changes/complete-socai2-investigation-chain/case-current-flow-20261110.md)和生产原答继续保留。
