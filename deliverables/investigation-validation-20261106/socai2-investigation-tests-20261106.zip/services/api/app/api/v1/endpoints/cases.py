"""First-class case management (tier2-cases).

Implements the full case lifecycle: new → triaged → investigating → contained →
resolved → closed.  Each case aggregates multiple alerts, maintains an observable
graph, evidence chain, and MITRE ATT&CK coverage map.

Tenant isolation
----------------
Every query in this module is scoped by ``tenant_id = user.tenant_id``. The
``aisoc_cases`` table has carried a ``tenant_id`` column since migration 012
but the API historically did not filter by it, allowing any authenticated
caller to read or mutate another tenant's cases just by guessing a UUID (or
by guessing the short ``INC-001`` form). Companion tables
(``aisoc_case_comments``, ``aisoc_case_tasks``) gained a ``tenant_id``
column in migration 044 and are backfilled from their parent case so the
same RLS predicate applies uniformly.

The ``_resolve_case_id`` helper is also tenant-scoped — looking up
``INC-001`` for tenant A must never return tenant B's INC-001.

Endpoints
---------
* ``GET  /cases``                  List cases (filterable by status/severity/assignee).
* ``POST /cases``                  Create a new case.
* ``GET  /cases/{id}``             Retrieve a case.
* ``PATCH /cases/{id}``            Update case fields (status, severity, assignee, …).
* ``POST /cases/{id}/alerts``      Link alerts to a case.
* ``POST /cases/{id}/observables`` Add / update observable graph nodes/edges.
* ``POST /cases/{id}/comments``    Add a comment / timeline entry.
* ``GET  /cases/{id}/comments``    List comments for a case.
* ``GET  /cases/{id}/evidence``    Export the evidence chain as a structured report.
"""

from __future__ import annotations

import json
import logging
import os
import re
import uuid
from datetime import UTC, datetime
from typing import Annotated, Any, Literal, cast
from urllib.parse import quote

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from fastapi.responses import HTMLResponse, PlainTextResponse
from pydantic import BaseModel, Field
from sqlalchemy import select, text

from app.api.v1.deps import AuthUser, DBSession, require_permission
from app.core.logging import safe_log_value
from app.services import case_orchestration, case_status, evidence_custody
from app.services.audit import emit_audit
from app.services.branding.resolver import resolve_branding
from app.services.case_fanout import (
    FanoutResult,
    fanout_create_case,
    fanout_status_change,
)
from app.services.case_postmortem import build_case_postmortem
from app.services.case_postmortem_html import render_case_postmortem_html
from app.services.case_summary import build_case_summary
from app.services.case_summary_html import render_case_summary_html
from app.services.semantic_memory import remember_closed_case

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/cases", tags=["cases"])

# The agents service owns the actual investigation orchestrator (Pillar-1).
# We keep the route surface on `/cases/{id}/investigate` and
# `/cases/{id}/investigations/{run_id}` for the web console and proxy through
# to the agents service so the front end has a single, stable API origin.
_AGENTS_URL = (os.getenv("AGENTS_SERVICE_URL") or os.getenv("AGENTS_API_URL") or "http://agents:8084").rstrip("/")

# The agents service guards its routes with require_console_or_service_auth:
# it accepts a console JWT or the shared service token paired with an explicit
# tenant header, and fails closed (401 "missing bearer credential") otherwise.
# This proxy forwards the user's *claims* but must present a credential of its
# own: the agents service does not share the API's user database. Resolve the
# same per-service token the agents service verifies (specific first, then
# shared), matching tenant_scope.resolve_service_token's precedence.
_AGENTS_SERVICE_TOKEN = (os.getenv("AISOC_AGENTS_SERVICE_TOKEN") or os.getenv("AISOC_SERVICE_TOKEN") or "").strip()


# Tight allowlist for proxied request paths. We only ever proxy to a fixed
# upstream (`_AGENTS_URL`) on a known set of investigation routes, so the
# path must be a pure relative path — no scheme, no host, no control bytes,
# no traversal sequences. This neutralises partial-SSRF (an attacker cannot
# redirect the request to a different host) and log-injection (the path
# can never contain CR/LF or other control characters).
_SAFE_PROXY_PATH_RE = re.compile(r"^/[A-Za-z0-9_\-./%]*$")


def _validate_agents_path(path: str) -> str:
    """Reject any proxied path that isn't a tightly constrained relative path."""
    if (
        not isinstance(path, str) or not _SAFE_PROXY_PATH_RE.match(path) or ".." in path or path.startswith("//")  # protocol-relative URL
    ):
        raise HTTPException(status_code=400, detail="invalid_request_path")
    return path


# ────────────────────────────────────────────────────────────────────────────
# Pydantic schemas
# ────────────────────────────────────────────────────────────────────────────

CaseStatus = Literal[
    "new",
    "triaged",
    "investigating",
    "contained",
    "resolved",
    "closed",
    # legacy/console aliases, normalized to the ladder above in update_case
    "open",
    "in_progress",
    "pending",
    "pending_closure",
    "cancelled",
]
CaseSeverity = Literal["info", "low", "medium", "high", "critical"]

# Valid forward-only state transitions
# One copy, in `case_status`. This used to be declared here and the
# metrics layer filtered on `"open"` and `"in_progress"` — states this
# machine cannot produce — so two surfaces disagreed about what a case
# status even is.
_TRANSITIONS: dict[str, set[str]] = case_status.TRANSITIONS

# The console historically spoke a second vocabulary (open/in_progress/pending/
# cancelled — see packages/types CaseStatus), so every status the UI can send
# is normalized onto the canonical ladder *before* the transition gate above
# runs. Aliases never bypass validation; they only translate the vocabulary.
_STATUS_ALIASES: dict[str, str] = {
    "open": "new",
    "in_progress": "investigating",
    "pending": "contained",
    "pending_closure": "contained",
    "cancelled": "closed",
}


def _normalize_status(status: str) -> CaseStatus:
    """Map a legacy write vocabulary onto the canonical ladder.

    Returns `CaseStatus` rather than `str` because the result is assigned back
    onto a `CaseStatus`-typed field: every alias resolves to a member of the
    ladder, and annotating it as `str` only moved the mismatch to the caller.
    """
    return cast("CaseStatus", _STATUS_ALIASES.get(status, status))


def _status_transition_ok(current: str, target: str) -> bool:
    """Upstream's canonical gate: every move must be a declared edge in
    `case_status.TRANSITIONS`. Backwards moves and undeclared skips are
    rejected; reopening goes through the explicit reopen action."""
    return target in _TRANSITIONS.get(current, set())


#: The canonical ladder, in order, for the forward-walk used by the
#: agent-launch advance.
_LADDER = list(case_status.ALL_STATUSES)


# Alert states from which launching an investigation may forward-advance an
# alert to 'investigating'. Terminal states (resolved/false_positive/closed)
# and an already-running alert are deliberately excluded: a re-run must never
# drag history backwards.
_ALERT_OPEN_STATUSES: tuple[str, ...] = ("new", "triaged", "triaging")


def _forward_to_investigating_ok(current: str) -> bool:
    """Can an agent-investigation launch move this case to investigating?

    Launching an investigation is a deliberate analyst action taken *on*
    the case, so it may walk the case forward along the canonical ladder
    (new -> triaged -> investigating) in one step. What it may never do
    is move backwards, re-hit the same state, or touch a terminal case --
    reopening remains the explicit POST /reopen path.
    """
    if current not in _LADDER or current in case_status.TERMINAL_STATUSES:
        return False
    return _LADDER.index(current) < _LADDER.index(case_status.INVESTIGATING)


class CreateCaseRequest(BaseModel):
    title: str = Field(..., min_length=3)
    description: str | None = None
    severity: CaseSeverity = "medium"
    assignee: str | None = None
    alert_ids: list[uuid.UUID] = Field(default_factory=list)
    mitre_techniques: list[str] = Field(default_factory=list)
    compliance_frameworks: list[str] = Field(default_factory=list)
    tags: dict[str, str] = Field(default_factory=dict)
    sla_due_at: datetime | None = None
    # Workstream 8 — bidirectional ITSM. When the operator selects one or
    # more connector instances at create time, the API fans the new case
    # out to those external systems and persists the linkage in
    # ``case_external_refs``. Connector instances must be tenant-owned,
    # enabled, and declare ``Capability.PUSH_CASE`` (e.g. Jira,
    # ServiceNow). Empty list = case stays AiSOC-only.
    push_to_connector_ids: list[uuid.UUID] = Field(default_factory=list)


class UpdateCaseRequest(BaseModel):
    title: str | None = None
    description: str | None = None
    severity: CaseSeverity | None = None
    status: CaseStatus | None = None
    assignee: str | None = None
    mitre_techniques: list[str] | None = None
    compliance_frameworks: list[str] | None = None
    tags: dict[str, str] | None = None
    sla_due_at: datetime | None = None


class AddAlertsRequest(BaseModel):
    alert_ids: list[uuid.UUID]


class ObservableNode(BaseModel):
    id: str
    kind: Literal["ip", "user", "host", "domain", "hash", "file", "process", "alert"]
    value: str
    tags: list[str] = Field(default_factory=list)


class ObservableEdge(BaseModel):
    source: str
    target: str
    relation: str


class UpdateObservablesRequest(BaseModel):
    nodes: list[ObservableNode] = Field(default_factory=list)
    edges: list[ObservableEdge] = Field(default_factory=list)


class AddCommentRequest(BaseModel):
    body: str = Field(..., min_length=1)
    is_system: bool = False


class CaseResponse(BaseModel):
    id: uuid.UUID
    case_number: str | None = None
    title: str
    description: str | None
    severity: str
    status: str
    assignee: str | None
    mitre_techniques: list[str]
    alert_ids: list[uuid.UUID]
    observable_graph: dict[str, Any]
    evidence_chain: list[dict[str, Any]]
    compliance_frameworks: list[str]
    opened_at: datetime
    triaged_at: datetime | None
    resolved_at: datetime | None
    closed_at: datetime | None
    #: When this case was last reopened. `None` means never -- which is the
    #: honest value for every row that predates migration 090, since we
    #: cannot know whether a historical case was reopened and inventing a
    #: timestamp would be worse than saying nothing.
    reopened_at: datetime | None = None
    #: How many times. `reopened_at` is overwritten on each reopen, so it
    #: cannot tell one reopen from four.
    reopen_count: int = 0
    reopen_reason: str | None = None
    created_at: datetime
    updated_at: datetime
    created_by: str | None
    tags: dict[str, Any]
    sla_due_at: datetime | None
    # Workstream 8 — populated only by ``POST /cases`` (create-time
    # fan-out) and ``PATCH /cases/{id}`` when ``status`` is changed.
    # The list is per-connector-instance and includes failures so the
    # UI can show "Jira ✓ · ServiceNow ✗ (timeout)" beside the case
    # without a follow-up GET. ``None`` (default) means "no fan-out
    # was attempted on this call" and is distinct from ``[]`` ("fan-out
    # was attempted but no connectors were selected").
    fanout_results: list[FanoutResult] | None = None


class CommentResponse(BaseModel):
    id: uuid.UUID
    case_id: uuid.UUID
    author: str | None
    body: str
    is_system: bool
    created_at: datetime


class EvidenceReport(BaseModel):
    case_id: uuid.UUID
    title: str
    severity: str
    status: str
    alert_count: int
    mitre_techniques: list[str]
    compliance_frameworks: list[str]
    evidence_chain: list[dict[str, Any]]
    generated_at: datetime


# Timeline / tasks
TaskStatus = Literal["todo", "in_progress", "done"]


class TimelineEvent(BaseModel):
    id: str
    type: str  # 'created' | 'status_change' | 'comment' | 'alert_linked' | 'task'
    timestamp: datetime
    title: str
    description: str | None = None
    actor: str | None = None


class TimelineResponse(BaseModel):
    events: list[TimelineEvent]


class CreateTaskRequest(BaseModel):
    title: str = Field(..., min_length=1)
    status: TaskStatus = "todo"
    assignee: str | None = None
    due_at: datetime | None = Field(None, alias="dueAt")

    model_config = {"populate_by_name": True}


class UpdateTaskRequest(BaseModel):
    title: str | None = None
    status: TaskStatus | None = None
    assignee: str | None = None
    due_at: datetime | None = Field(None, alias="dueAt")

    model_config = {"populate_by_name": True}


class TaskResponse(BaseModel):
    id: str
    title: str
    status: TaskStatus
    assignee: str | None = None
    due_at: datetime | None = Field(None, alias="dueAt")
    created_at: datetime = Field(..., alias="createdAt")

    model_config = {"populate_by_name": True}


def _row_to_task(row: Any) -> TaskResponse:
    return TaskResponse(
        id=str(row.id),
        title=row.title,
        status=row.status,
        assignee=row.assignee,
        dueAt=row.due_at,
        createdAt=row.created_at,
    )


# Investigation proxy schemas (forwarded to the agents service).
class InvestigateRequest(BaseModel):
    alert_summary: str | None = ""


# ────────────────────────────────────────────────────────────────────────────
# Helpers
# ────────────────────────────────────────────────────────────────────────────


def _coerce_mitre(values: Any) -> list[str]:
    """Normalize mitre_techniques to a list of technique IDs.

    Accepts list[str] or list[dict] like ``{"id": "T1041", "name": "..."}``.
    Older seed fixtures stored objects; newer ones store flat IDs.
    """
    if not values:
        return []
    out: list[str] = []
    for item in values:
        if isinstance(item, str):
            out.append(item)
        elif isinstance(item, dict):
            tid = item.get("id") or item.get("technique_id") or item.get("name")
            if tid:
                out.append(str(tid))
    return out


def _coerce_tags(value: Any) -> dict[str, Any]:
    """aisoc_cases.tags is JSONB which may be an object or array."""
    if isinstance(value, dict):
        return value
    if isinstance(value, list):
        return {"labels": [str(v) for v in value]}
    return {}


def _row_to_case(row: Any) -> CaseResponse:
    return CaseResponse(
        id=row.id,
        case_number=getattr(row, "case_number", None),
        title=row.title,
        description=row.description,
        severity=row.severity,
        status=row.status,
        # `getattr` with a default because this mapper is also handed rows
        # from queries that select an explicit column list.
        reopened_at=getattr(row, "reopened_at", None),
        reopen_count=getattr(row, "reopen_count", 0) or 0,
        reopen_reason=getattr(row, "reopen_reason", None),
        assignee=row.assignee,
        mitre_techniques=_coerce_mitre(row.mitre_techniques),
        alert_ids=list(row.alert_ids or []),
        observable_graph=dict(row.observable_graph or {}),
        evidence_chain=list(row.evidence_chain or []),
        compliance_frameworks=list(row.compliance_frameworks or []),
        opened_at=row.opened_at,
        triaged_at=row.triaged_at,
        resolved_at=row.resolved_at,
        closed_at=row.closed_at,
        created_at=row.created_at,
        updated_at=row.updated_at,
        created_by=row.created_by,
        tags=_coerce_tags(row.tags),
        sla_due_at=row.sla_due_at,
    )


async def _resolve_case_id(case_id: str, db: Any, tenant_id: uuid.UUID) -> uuid.UUID:
    """Resolve a case identifier (UUID **or** human-readable case_number) to a UUID
    scoped to the caller's tenant.

    The web console and demo deeplinks use short identifiers like ``INC-001``,
    while the database primary key is a UUID. Accepting both forms here keeps
    the API ergonomic without forcing the front end to do a separate lookup.

    Tenant scoping is enforced in both branches:

    * For the UUID branch we return the parsed UUID without touching the DB;
      callers must still apply ``WHERE tenant_id = :tenant_id`` in their own
      query, which they all do. (We don't probe existence here because every
      caller does its own SELECT and would issue a redundant round-trip.)
    * For the ``case_number`` branch we look up the row with
      ``WHERE tenant_id = :tenant_id AND case_number = :case_number`` so an
      attacker can't enumerate another tenant's INC-NNN identifiers.

    Raises ``404`` if the identifier doesn't match either form within the
    caller's tenant.
    """
    case_id = (case_id or "").strip()
    if not case_id:
        raise HTTPException(status_code=404, detail="Case not found.")

    # Try UUID first — that's the canonical form. Tenant scoping is enforced
    # by the per-endpoint queries that consume the returned UUID, so we
    # don't need a DB round-trip just to validate the format.
    try:
        return uuid.UUID(case_id)
    except (ValueError, AttributeError):
        pass

    # Fall back to case_number lookup. Use a parameterized query — never
    # interpolate the raw string into SQL — and scope by tenant so the
    # short-id form can't be used as a cross-tenant oracle.
    row = (
        await db.execute(
            text(
                "SELECT id FROM aisoc_cases WHERE tenant_id = :tenant_id AND case_number = :case_number ORDER BY created_at DESC LIMIT 1"
            ).bindparams(tenant_id=tenant_id, case_number=case_id)
        )
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Case not found.")
    return row.id


# ────────────────────────────────────────────────────────────────────────────
# Endpoints
# ────────────────────────────────────────────────────────────────────────────


@router.get("", response_model=list[CaseResponse], summary="List cases")
async def list_cases(
    db: DBSession,
    user: AuthUser,
    status_filter: str | None = Query(None, alias="status"),
    severity: str | None = Query(None),
    assignee: str | None = Query(None),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
) -> list[CaseResponse]:
    # Tenant scoping is non-optional. The aisoc_cases table has carried a
    # tenant_id column since migration 012; until P2-W1 the API simply
    # ignored it, exposing every tenant's caseload to every authenticated
    # caller. Anchor the WHERE clause on tenant_id so the filter is always
    # present even when the operator passes no other filters.
    where_clauses = ["tenant_id = :tenant_id"]
    params: dict[str, Any] = {
        "limit": limit,
        "offset": offset,
        "tenant_id": user.tenant_id,
    }
    if status_filter:
        where_clauses.append("status = :status")
        params["status"] = status_filter
    if severity:
        where_clauses.append("severity = :severity")
        params["severity"] = severity
    if assignee:
        where_clauses.append("assignee = :assignee")
        params["assignee"] = assignee

    q = f"""
        SELECT * FROM aisoc_cases
        WHERE {" AND ".join(where_clauses)}
        ORDER BY created_at DESC
        LIMIT :limit OFFSET :offset
    """
    try:
        rows = await db.execute(text(q).bindparams(**params))
        return [_row_to_case(r) for r in rows.fetchall()]
    except Exception as exc:
        logger.exception("Database error in cases endpoint")
        raise HTTPException(status_code=503, detail="Database error") from exc


@router.post("", response_model=CaseResponse, status_code=status.HTTP_201_CREATED, summary="Create case")
async def create_case(
    body: CreateCaseRequest, db: DBSession, user: Annotated[AuthUser, Depends(require_permission("cases:write"))]
) -> CaseResponse:
    import json as _json

    case_id = uuid.uuid4()
    now = datetime.now(UTC)
    # Note: PostgreSQL ``::type`` casts inside text() confuse SQLAlchemy's
    # bind-parameter parser; use ``CAST(:param AS TYPE)`` so the bind survives
    # the round-trip (see also Batch 2 / hunts.py for the same gotcha).
    q = text("""
        INSERT INTO aisoc_cases (
            id, tenant_id, title, description, severity, status, assignee,
            mitre_techniques, alert_ids, compliance_frameworks, tags,
            sla_due_at, opened_at, created_at, updated_at, created_by
        ) VALUES (
            :id, :tenant_id, :title, :description, :severity, 'new', :assignee,
            CAST(:mitre AS JSONB), CAST(:alert_ids AS UUID[]),
            CAST(:frameworks AS TEXT[]), CAST(:tags AS JSONB),
            :sla, :now, :now, :now, :user
        ) RETURNING *
    """).bindparams(
        id=case_id,
        tenant_id=user.tenant_id,
        title=body.title,
        description=body.description,
        severity=body.severity,
        assignee=body.assignee,
        mitre=_json.dumps(body.mitre_techniques),
        alert_ids=list(map(str, body.alert_ids)) or [],
        frameworks=body.compliance_frameworks or [],
        tags=_json.dumps(body.tags),
        sla=body.sla_due_at,
        now=now,
        user=getattr(user, "email", None) or "system",
    )
    try:
        row = (await db.execute(q)).fetchone()
        if row is None:
            raise HTTPException(status_code=503, detail="Database error: INSERT returned no row")
        await db.commit()
    except Exception as exc:
        await db.rollback()
        logger.exception("Database error in cases endpoint")
        raise HTTPException(status_code=503, detail="Database error") from exc

    response = _row_to_case(row)

    # Workstream 8 — fan out to operator-selected ITSM connectors. The
    # case is already persisted (commit above) so a flaky Jira can't
    # block the create. ``fanout_create_case`` swallows per-backend
    # errors into the FanoutResult.status field; we only need to
    # commit the ``case_external_refs`` writes it staged.
    if body.push_to_connector_ids:
        try:
            results = await fanout_create_case(
                db,
                case_row=row,
                tenant_id=user.tenant_id,
                connector_ids=body.push_to_connector_ids,
                pushed_by=getattr(user, "email", None),
            )
            await db.commit()
            response.fanout_results = results
        except Exception:
            # Persistence of external refs failed but the AiSOC case
            # itself is fine; surface the partial result and move on.
            logger.exception("cases.create.fanout_persistence_failed case=%s", row.id)
            await db.rollback()
            response.fanout_results = []

    return response


@router.get("/{case_id}", response_model=CaseResponse, summary="Get case")
async def get_case(case_id: str, db: DBSession, user: AuthUser) -> CaseResponse:
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    row = (
        await db.execute(
            text("SELECT * FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(id=cid, tenant_id=user.tenant_id)
        )
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Case not found.")
    return _row_to_case(row)


class ReopenCaseRequest(BaseModel):
    """Why this case is coming back."""

    reason: str = Field(
        min_length=8,
        max_length=2000,
        description="Why the case is being reopened. Recorded on the case and in the audit log.",
    )
    #: Where it lands. Restricted to the states a case can genuinely resume
    #: in -- reopening straight to `contained` would assert a containment
    #: nobody performed on this pass.
    status: Literal["new", "triaged", "investigating"] = "investigating"


@router.post("/{case_id}/reopen", response_model=CaseResponse, summary="Reopen a closed case")
async def reopen_case(
    case_id: str,
    body: ReopenCaseRequest,
    db: DBSession,
    user: Annotated[AuthUser, Depends(require_permission("cases:write"))],
) -> CaseResponse:
    """Bring a terminal case back, deliberately and on the record.

    Its own route rather than a backward edge in `TRANSITIONS`. The forward-only
    machine is what makes "this case was closed" mean something, and adding
    `closed -> investigating` to the table would let an ordinary `PATCH` --
    a title edit that happens to carry a status -- walk a case backwards
    silently. `PATCH` stays forward-only.

    Three things separate this from a status change:

    * a reason is required, because an unexplained reopen is exactly what an
      auditor asks about six months later;
    * `reopen_count` increments, so a case reopened four times is
      distinguishable from one reopened once;
    * `closed_at` and `resolved_at` are cleared, because leaving them set
      would make the case terminal and active at the same time -- and every
      closure metric reads those columns.
    """
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    existing = (
        await db.execute(
            text("SELECT status, reopen_count FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(
                id=cid, tenant_id=user.tenant_id
            )
        )
    ).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Case not found.")

    if existing.status not in case_status.TERMINAL_STATUSES:
        raise HTTPException(
            status_code=409,
            detail=(
                f"Case is {existing.status!r}, which is not a terminal state, so there is nothing "
                f"to reopen. Use PATCH to move it to {sorted(case_status.TRANSITIONS.get(existing.status, set()))}."
            ),
        )

    now = datetime.now(UTC)
    await db.execute(
        text(
            """
            UPDATE aisoc_cases
               SET status = :status,
                   reopened_at = :now,
                   reopen_count = COALESCE(reopen_count, 0) + 1,
                   reopen_reason = :reason,
                   -- Cleared deliberately: a case that is open again has not
                   -- been closed, and every closure metric reads these.
                   closed_at = NULL,
                   resolved_at = NULL,
                   updated_at = :now
             WHERE id = :id AND tenant_id = :tenant_id
            """
        ).bindparams(
            status=body.status,
            now=now,
            reason=body.reason,
            id=cid,
            tenant_id=user.tenant_id,
        )
    )
    await db.commit()

    try:
        await emit_audit(
            db=db,
            tenant_id=user.tenant_id,
            actor_id=user.user_id,
            actor_email=user.email,
            action="case.reopen",
            resource="case",
            resource_id=str(cid),
            changes={
                "from_status": existing.status,
                "to_status": body.status,
                "reason": body.reason,
                "reopen_count": (existing.reopen_count or 0) + 1,
            },
            # Which credential, not just which person. A key owned by an
            # analyst resolves to that analyst's email, so without this an
            # auditor cannot tell "Dana reopened this at her console" from "a
            # key Dana minted a year ago reopened it from a script" -- and
            # those call for different responses.
            api_key_prefix=getattr(user, "api_key_prefix", None),
        )
    except Exception:  # noqa: BLE001 - an audit failure must not undo the reopen
        # Roll the *failed audit attempt* back, not the reopen: that already
        # committed above. Without this the session stays in a failed
        # transaction and the read below raises, so an audit problem would
        # surface to the caller as the reopen itself failing -- when in fact
        # it succeeded and only the log entry did not. A live test caught
        # exactly that.
        await db.rollback()
        logger.exception("cases.reopen.audit_failed case=%s", cid)

    row = (
        await db.execute(
            text("SELECT * FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(id=cid, tenant_id=user.tenant_id)
        )
    ).fetchone()
    return _row_to_case(row)


@router.patch("/{case_id}", response_model=CaseResponse, summary="Update case")
async def update_case(
    case_id: str, body: UpdateCaseRequest, db: DBSession, user: Annotated[AuthUser, Depends(require_permission("cases:write"))]
) -> CaseResponse:
    import json as _json

    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    existing = (
        await db.execute(
            text("SELECT status FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(id=cid, tenant_id=user.tenant_id)
        )
    ).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Case not found.")

    if body.status is not None:
        body.status = _normalize_status(body.status)
    if body.status and body.status != existing.status:
        if not _status_transition_ok(existing.status, body.status):
            raise HTTPException(
                status_code=422,
                detail=(
                    f"Invalid status transition: {existing.status} → {body.status}. "
                    f"Allowed: {sorted(_TRANSITIONS.get(existing.status, set())) or 'none'}; "
                    "backwards moves require POST /cases/{id}/reopen."
                ),
            )

    now = datetime.now(UTC)
    sets = ["updated_at = :now"]
    params: dict[str, Any] = {
        "id": cid,
        "now": now,
        "tenant_id": user.tenant_id,
    }

    if body.title is not None:
        sets.append("title = :title")
        params["title"] = body.title
    if body.description is not None:
        sets.append("description = :description")
        params["description"] = body.description
    if body.severity is not None:
        sets.append("severity = :severity")
        params["severity"] = body.severity
    if body.assignee is not None:
        sets.append("assignee = :assignee")
        params["assignee"] = body.assignee
    if body.sla_due_at is not None:
        sets.append("sla_due_at = :sla")
        params["sla"] = body.sla_due_at
    if body.mitre_techniques is not None:
        sets.append("mitre_techniques = CAST(:mitre AS JSONB)")
        params["mitre"] = _json.dumps(body.mitre_techniques)
    if body.compliance_frameworks is not None:
        sets.append("compliance_frameworks = CAST(:frameworks AS TEXT[])")
        params["frameworks"] = body.compliance_frameworks
    if body.tags is not None:
        sets.append("tags = CAST(:tags AS JSONB)")
        params["tags"] = _json.dumps(body.tags)

    if body.status:
        sets.append("status = :status")
        params["status"] = body.status
        ts_col = {"triaged": "triaged_at", "resolved": "resolved_at", "closed": "closed_at"}.get(body.status)
        if ts_col:
            sets.append(f"{ts_col} = :now")

    q = text(f"UPDATE aisoc_cases SET {', '.join(sets)} WHERE id = :id AND tenant_id = :tenant_id RETURNING *").bindparams(**params)
    try:
        row = (await db.execute(q)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Case not found.")
        if body.status is not None:
            await _append_custody(
                db,
                case_id=cid,
                tenant_id=user.tenant_id,
                user=user,
                action="case_closed" if body.status == "closed" else "status_changed",
                item=body.status,
                detail={"to": body.status},
            )
        await db.commit()
    except Exception as exc:
        await db.rollback()
        logger.exception("Database error in cases endpoint")
        raise HTTPException(status_code=503, detail="Database error") from exc

    response = _row_to_case(row)

    # Depth 9.2. A closed case is the first of the three things parity 6.5
    # names as semantic memory, and nothing else writes `kind='case'` -- so
    # without this call that half of the store would be permanently empty on
    # every deployment where nobody ingests by hand, which is the half of the
    # "exists unwired" family that reachability analysis cannot see.
    #
    # After the commit and fail-soft on purpose: closing a case must not 503
    # because a vector store is down. The row is written in its own
    # transaction, and `/memory/status` reports how many rows are waiting to
    # be embedded so a degraded store is visible rather than silent.
    if body.status == "closed" and body.status != existing.status:
        try:
            await remember_closed_case(
                db,
                tenant_id=user.tenant_id,
                case_id=cid,
                title=response.title,
                summary=response.description or "",
                author=getattr(user, "email", "") or "",
            )
            await db.commit()
        except Exception:  # noqa: BLE001 - see above; never fails the close
            await db.rollback()
            logger.warning("semantic memory: could not record closed case %s", cid, exc_info=True)

    # Workstream 8 — if the operator changed status, project the
    # transition onto every connector this case is already linked to.
    # ``fanout_status_change`` no-ops when the case has no
    # ``case_external_refs`` rows yet, so the call is cheap for
    # AiSOC-only cases.
    if body.status and body.status != existing.status:
        try:
            results = await fanout_status_change(
                db,
                case_row=row,
                tenant_id=user.tenant_id,
                old_status=existing.status,
                new_status=body.status,
                pushed_by=getattr(user, "email", None),
            )
            if results:
                await db.commit()
                response.fanout_results = results
        except Exception:
            logger.exception("cases.update.fanout_persistence_failed case=%s", row.id)
            await db.rollback()
            response.fanout_results = []

        # WS-D2 — when a case enters its terminal lifecycle stages, drop a
        # system note pointing to the auto-summary artifact. The summary
        # itself is generated on-demand by GET /cases/{id}/summary, so this
        # is a cheap, idempotent breadcrumb rather than a heavy precompute.
        if body.status in {"resolved", "closed"}:
            try:
                await _emit_summary_breadcrumb(
                    db,
                    case_id=row.id,
                    tenant_id=user.tenant_id,
                    status=body.status,
                )
            except Exception:  # pragma: no cover — defensive: never block status change.
                logger.exception("cases.update.summary_breadcrumb_failed case=%s", row.id)
                await db.rollback()

    return response


# ─────────────────────────────────────────────────────────────────────────────
# Evidence custody
#
# `evidence_chain` had three readers and no writer, so the report an auditor
# exports from `GET /cases/{id}/evidence` was always `[]` under a heading
# saying "Evidence Chain" — which reads as "no evidence was handled" rather
# than "this product does not record custody".
#
# Appended in the same statement that performs the mutation being recorded,
# so a custody entry cannot exist for a change that did not commit, and a
# change cannot commit without its entry.
# ─────────────────────────────────────────────────────────────────────────────


async def _append_custody(
    db: Any,
    *,
    case_id: Any,
    tenant_id: Any,
    user: AuthUser,
    action: str,
    item: str | None = None,
    detail: dict[str, Any] | None = None,
) -> None:
    """Append one custody entry to this case's chain.

    Reads the current chain to link the hash, then writes the extended
    chain back. Best-effort by design: a custody write that failed must
    not roll back the case change an analyst just made, because losing
    the work is worse than losing one audit line. The failure is logged
    at `warning` so it is visible rather than silent.
    """
    try:
        current = await db.scalar(
            text("SELECT evidence_chain FROM aisoc_cases WHERE id = :id AND tenant_id = :t").bindparams(id=case_id, t=tenant_id)
        )
        chain = evidence_custody.append_entry(
            list(current or []),
            action=action,
            actor_id=getattr(user, "user_id", None),
            actor_email=getattr(user, "email", None),
            item=item,
            detail=detail,
        )
        await db.execute(
            text("UPDATE aisoc_cases SET evidence_chain = CAST(:c AS jsonb) WHERE id = :id AND tenant_id = :t").bindparams(
                c=json.dumps(chain), id=case_id, t=tenant_id
            )
        )
    except Exception as exc:  # noqa: BLE001 - never fail the caller's mutation
        logger.warning(
            "cases.custody_append_failed action=%s error=%s",
            str(action).replace("\r", "").replace("\n", " ")[:80],
            str(exc).replace("\r", "").replace("\n", " ")[:200],
        )


def case_queue_for(case_row: Any, queues: list[Any]) -> Any:
    """Which queue this case belongs in.

    Routed through `case_orchestration.resolve_queue` so precedence and
    the name tiebreak live in one place — without the tiebreak two
    equally-ranked queues resolve by row order and a case appears to
    move between them on each read.
    """
    return case_orchestration.resolve_queue(
        case_orchestration.CaseFacts(
            severity=str(getattr(case_row, "severity", "medium") or "medium"),
            case_type=getattr(case_row, "case_type", None),
            tags=tuple(getattr(case_row, "tags", None) or ()),
            opened_at=getattr(case_row, "opened_at", None),
        ),
        queues,
    )


@router.post("/{case_id}/alerts", response_model=CaseResponse, summary="Link alerts to a case")
async def add_alerts(
    case_id: str, body: AddAlertsRequest, db: DBSession, user: Annotated[AuthUser, Depends(require_permission("cases:write"))]
) -> CaseResponse:
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    ids_str = [str(a) for a in body.alert_ids]
    q = text("""
        UPDATE aisoc_cases
        SET alert_ids = array(SELECT DISTINCT unnest(alert_ids || CAST(:new_ids AS UUID[]))),
            updated_at = now()
        WHERE id = :id AND tenant_id = :tenant_id
        RETURNING *
    """).bindparams(id=cid, new_ids=ids_str, tenant_id=user.tenant_id)
    try:
        row = (await db.execute(q)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Case not found.")
        await _append_custody(
            db,
            case_id=cid,
            tenant_id=user.tenant_id,
            user=user,
            action="alert_linked",
            item=",".join(ids_str[:20]),
            detail={"count": len(ids_str)},
        )
        await db.commit()
        refreshed = (
            await db.execute(text("SELECT * FROM aisoc_cases WHERE id = :id AND tenant_id = :t").bindparams(id=cid, t=user.tenant_id))
        ).fetchone()
        return _row_to_case(refreshed or row)
    except HTTPException:
        raise
    except Exception as exc:
        await db.rollback()
        logger.exception("Database error in cases endpoint")
        raise HTTPException(status_code=503, detail="Database error") from exc


@router.post("/{case_id}/observables", response_model=CaseResponse, summary="Update observable graph")
async def update_observables(
    case_id: str, body: UpdateObservablesRequest, db: DBSession, user: Annotated[AuthUser, Depends(require_permission("cases:write"))]
) -> CaseResponse:
    import json as _json

    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    existing = (
        await db.execute(
            text("SELECT observable_graph FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(
                id=cid, tenant_id=user.tenant_id
            )
        )
    ).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Case not found.")

    graph: dict[str, Any] = dict(existing.observable_graph or {})
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])

    existing_ids = {n["id"] for n in nodes}
    for n in body.nodes:
        if n.id not in existing_ids:
            nodes.append(n.model_dump())
        else:
            nodes = [n.model_dump() if x["id"] == n.id else x for x in nodes]

    edge_keys = {(e["source"], e["target"]) for e in edges}
    for e in body.edges:
        if (e.source, e.target) not in edge_keys:
            edges.append(e.model_dump())

    graph = {"nodes": nodes, "edges": edges}
    q = text(
        "UPDATE aisoc_cases SET observable_graph = CAST(:g AS JSONB), updated_at = now() "
        "WHERE id = :id AND tenant_id = :tenant_id RETURNING *"
    ).bindparams(id=cid, g=_json.dumps(graph), tenant_id=user.tenant_id)
    try:
        row = (await db.execute(q)).fetchone()
        await db.commit()
        return _row_to_case(row)
    except Exception as exc:
        await db.rollback()
        logger.exception("Database error in cases endpoint")
        raise HTTPException(status_code=503, detail="Database error") from exc


@router.post("/{case_id}/comments", response_model=CommentResponse, status_code=201, summary="Add comment")
async def add_comment(
    case_id: str, body: AddCommentRequest, db: DBSession, user: Annotated[AuthUser, Depends(require_permission("cases:write"))]
) -> CommentResponse:
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    exists = (
        await db.execute(
            text("SELECT 1 FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(id=cid, tenant_id=user.tenant_id)
        )
    ).fetchone()
    if not exists:
        raise HTTPException(status_code=404, detail="Case not found.")

    comment_id = uuid.uuid4()
    now = datetime.now(UTC)
    # Stamp the row with tenant_id so the comment table is independently
    # tenant-scoped — see migration 044.
    q = text("""
        INSERT INTO aisoc_case_comments
            (id, case_id, tenant_id, author, body, is_system, created_at)
        VALUES
            (:id, :case_id, :tenant_id, :author, :body, :sys, :now)
        RETURNING *
    """).bindparams(
        id=comment_id,
        case_id=cid,
        tenant_id=user.tenant_id,
        author=getattr(user, "email", None) or "system",
        body=body.body,
        sys=body.is_system,
        now=now,
    )
    try:
        row = (await db.execute(q)).fetchone()
        if row is None:
            raise HTTPException(status_code=503, detail="Database error: INSERT returned no row")
        await db.commit()
        return CommentResponse(
            id=row.id,
            case_id=row.case_id,
            author=row.author,
            body=row.body,
            is_system=row.is_system,
            created_at=row.created_at,
        )
    except Exception as exc:
        await db.rollback()
        logger.exception("Database error in cases endpoint")
        raise HTTPException(status_code=503, detail="Database error") from exc


@router.get("/{case_id}/comments", response_model=list[CommentResponse], summary="List case comments")
async def list_comments(case_id: str, db: DBSession, user: AuthUser) -> list[CommentResponse]:
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    rows = (
        await db.execute(
            text("SELECT * FROM aisoc_case_comments WHERE case_id = :id AND tenant_id = :tenant_id ORDER BY created_at").bindparams(
                id=cid, tenant_id=user.tenant_id
            )
        )
    ).fetchall()
    return [
        CommentResponse(id=r.id, case_id=r.case_id, author=r.author, body=r.body, is_system=r.is_system, created_at=r.created_at)
        for r in rows
    ]


# Alias `/notes` → `/comments` so the web console (which calls `/notes` for the
# "Add Note" affordance) hits the same backing store.  Keeping both routes
# avoids a behavior change for any existing integration that already speaks
# `/comments`.
@router.get("/{case_id}/notes", response_model=list[CommentResponse], summary="List case notes (alias of /comments)")
async def list_notes(case_id: str, db: DBSession, user: AuthUser) -> list[CommentResponse]:
    return await list_comments(case_id, db, user)


@router.post("/{case_id}/notes", response_model=CommentResponse, status_code=201, summary="Add case note (alias of /comments)")
async def add_note(
    case_id: str, body: AddCommentRequest, db: DBSession, user: Annotated[AuthUser, Depends(require_permission("cases:write"))]
) -> CommentResponse:
    return await add_comment(case_id, body, db, user)


@router.get("/{case_id}/evidence", response_model=EvidenceReport, summary="Export evidence chain report")
async def evidence_report(case_id: str, db: DBSession, user: AuthUser) -> EvidenceReport:
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    row = (
        await db.execute(
            text("SELECT * FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(id=cid, tenant_id=user.tenant_id)
        )
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Case not found.")
    return EvidenceReport(
        case_id=row.id,
        title=row.title,
        severity=row.severity,
        status=row.status,
        alert_count=len(row.alert_ids or []),
        mitre_techniques=_coerce_mitre(row.mitre_techniques),
        compliance_frameworks=list(row.compliance_frameworks or []),
        evidence_chain=list(row.evidence_chain or []),
        generated_at=datetime.now(UTC),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Timeline
#
# A flattened activity stream that the case workspace renders on the right.
# We synthesize the timeline from the case's own state transitions, linked
# alerts, comments, and tasks so the front end gets one unified view without
# orchestrating four separate calls.
# ─────────────────────────────────────────────────────────────────────────────


@router.get("/{case_id}/timeline", response_model=TimelineResponse, summary="Case activity timeline")
async def case_timeline(case_id: str, db: DBSession, user: AuthUser) -> TimelineResponse:
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    case_row = (
        await db.execute(
            text("SELECT * FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(id=cid, tenant_id=user.tenant_id)
        )
    ).fetchone()
    if not case_row:
        raise HTTPException(status_code=404, detail="Case not found.")

    events: list[TimelineEvent] = []

    # Case creation event
    events.append(
        TimelineEvent(
            id=f"case-{case_row.id}-created",
            type="created",
            timestamp=case_row.created_at,
            title="Case opened",
            description=case_row.title,
            actor=case_row.assignee,
        )
    )

    # Status / severity reflection (we only surface the latest snapshot here;
    # full audit history is available via the audit log endpoints).
    if case_row.updated_at and case_row.updated_at != case_row.created_at:
        events.append(
            TimelineEvent(
                id=f"case-{case_row.id}-status",
                type="status_change",
                timestamp=case_row.updated_at,
                title=f"Status: {case_row.status}",
                description=f"Severity {case_row.severity}",
                actor=case_row.assignee,
            )
        )

    # Comments
    comment_rows = (
        await db.execute(
            text(
                "SELECT id, author, body, is_system, created_at "
                "FROM aisoc_case_comments "
                "WHERE case_id = :id AND tenant_id = :tenant_id "
                "ORDER BY created_at"
            ).bindparams(id=cid, tenant_id=user.tenant_id)
        )
    ).fetchall()
    for c in comment_rows:
        events.append(
            TimelineEvent(
                id=f"comment-{c.id}",
                type="comment",
                timestamp=c.created_at,
                title="System note" if c.is_system else "Comment",
                description=(c.body or "")[:280],
                actor=c.author,
            )
        )

    # Linked alerts (best-effort — we tolerate a missing alerts table)
    for alert_id in list(case_row.alert_ids or [])[:25]:
        try:
            a = (
                # Tenant-scoped as defence in depth. Reaching this loop already
                # required a tenant-scoped case, but the predicate costs
                # nothing and a poisoned ``alert_ids`` array would otherwise
                # hydrate another tenant's alert title into this timeline.
                await db.execute(
                    text(
                        "SELECT id, title, severity, created_at FROM alerts WHERE id = :id AND tenant_id = CAST(:tenant_id AS uuid)"
                    ).bindparams(
                        id=alert_id,
                        tenant_id=str(user.tenant_id),
                    )
                )
            ).fetchone()
            if a:
                events.append(
                    TimelineEvent(
                        id=f"alert-{a.id}",
                        type="alert_linked",
                        timestamp=a.created_at or case_row.created_at,
                        title=f"Alert linked: {a.title}",
                        description=f"Severity {a.severity}",
                        actor=None,
                    )
                )
        except Exception:  # noqa: BLE001 — alerts table may not exist in some demos
            continue

    # Tasks
    try:
        task_rows = (
            await db.execute(
                text(
                    "SELECT id, title, status, assignee, created_at "
                    "FROM aisoc_case_tasks "
                    "WHERE case_id = :id AND tenant_id = :tenant_id "
                    "ORDER BY created_at"
                ).bindparams(id=cid, tenant_id=user.tenant_id)
            )
        ).fetchall()
        for t in task_rows:
            events.append(
                TimelineEvent(
                    id=f"task-{t.id}",
                    type="task",
                    timestamp=t.created_at,
                    title=f"Task ({t.status}): {t.title}",
                    description=None,
                    actor=t.assignee,
                )
            )
    except Exception:  # noqa: BLE001 — table created by migration 027; tolerate absence
        logger.exception("aisoc_case_tasks not available; skipping task events")

    events.sort(key=lambda e: e.timestamp)
    return TimelineResponse(events=events)


# ─────────────────────────────────────────────────────────────────────────────
# Tasks
# ─────────────────────────────────────────────────────────────────────────────


@router.get("/{case_id}/tasks", response_model=list[TaskResponse], summary="List case tasks")
async def list_tasks(case_id: str, db: DBSession, user: AuthUser) -> list[TaskResponse]:
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    exists = (
        await db.execute(
            text("SELECT 1 FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(id=cid, tenant_id=user.tenant_id)
        )
    ).fetchone()
    if not exists:
        raise HTTPException(status_code=404, detail="Case not found.")
    rows = (
        await db.execute(
            text(
                "SELECT id, title, status, assignee, due_at, created_at "
                "FROM aisoc_case_tasks "
                "WHERE case_id = :id AND tenant_id = :tenant_id "
                "ORDER BY created_at"
            ).bindparams(id=cid, tenant_id=user.tenant_id)
        )
    ).fetchall()
    return [_row_to_task(r) for r in rows]


@router.post("/{case_id}/tasks", response_model=TaskResponse, status_code=201, summary="Create task")
async def create_task(
    case_id: str,
    body: CreateTaskRequest,
    db: DBSession,
    user: Annotated[AuthUser, Depends(require_permission("cases:write"))],
) -> TaskResponse:
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    exists = (
        await db.execute(
            text("SELECT 1 FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(id=cid, tenant_id=user.tenant_id)
        )
    ).fetchone()
    if not exists:
        raise HTTPException(status_code=404, detail="Case not found.")

    task_id = uuid.uuid4()
    now = datetime.now(UTC)
    try:
        row = (
            await db.execute(
                text(
                    """
                    INSERT INTO aisoc_case_tasks
                        (id, case_id, tenant_id, title, status, assignee, due_at, created_at, updated_at, created_by)
                    VALUES
                        (:id, :case_id, :tenant_id, :title, :status, :assignee, :due_at, :now, :now, :created_by)
                    RETURNING id, title, status, assignee, due_at, created_at
                    """
                ).bindparams(
                    id=task_id,
                    case_id=cid,
                    tenant_id=user.tenant_id,
                    title=body.title,
                    status=body.status,
                    assignee=body.assignee,
                    due_at=body.due_at,
                    now=now,
                    created_by=getattr(user, "email", None) or "system",
                )
            )
        ).fetchone()
        await db.commit()
        return _row_to_task(row)
    except Exception as exc:
        await db.rollback()
        logger.exception("Database error in cases endpoint")
        raise HTTPException(status_code=503, detail="Database error") from exc


@router.patch("/{case_id}/tasks/{task_id}", response_model=TaskResponse, summary="Update task")
async def update_task(
    case_id: str,
    task_id: uuid.UUID,
    body: UpdateTaskRequest,
    db: DBSession,
    user: Annotated[AuthUser, Depends(require_permission("cases:write"))],
) -> TaskResponse:
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    sets: list[str] = []
    params: dict[str, Any] = {
        "id": task_id,
        "case_id": cid,
        "tenant_id": user.tenant_id,
        "now": datetime.now(UTC),
    }
    if body.title is not None:
        sets.append("title = :title")
        params["title"] = body.title
    if body.status is not None:
        sets.append("status = :status")
        params["status"] = body.status
    if body.assignee is not None:
        sets.append("assignee = :assignee")
        params["assignee"] = body.assignee
    if body.due_at is not None:
        sets.append("due_at = :due_at")
        params["due_at"] = body.due_at
    if not sets:
        raise HTTPException(status_code=400, detail="No fields to update.")
    sets.append("updated_at = :now")

    try:
        row = (
            await db.execute(
                text(
                    f"""
                    UPDATE aisoc_case_tasks
                    SET {", ".join(sets)}
                    WHERE id = :id AND case_id = :case_id AND tenant_id = :tenant_id
                    RETURNING id, title, status, assignee, due_at, created_at
                    """
                ).bindparams(**params)
            )
        ).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Task not found.")
        await db.commit()
        return _row_to_task(row)
    except HTTPException:
        raise
    except Exception as exc:
        await db.rollback()
        logger.exception("Database error in cases endpoint")
        raise HTTPException(status_code=503, detail="Database error") from exc


# ─────────────────────────────────────────────────────────────────────────────
# Investigation proxy
#
# The investigation orchestrator lives in the agents service. The web console
# only knows about /api/v1/cases/{id}/..., so we proxy through and keep the
# external API surface stable.
# ─────────────────────────────────────────────────────────────────────────────


async def _agents_proxy(method: str, path: str, **kwargs: Any) -> httpx.Response:
    safe_path = _validate_agents_path(path)
    url = f"{_AGENTS_URL}{safe_path}"
    timeout = kwargs.pop("timeout", 30.0)
    headers = dict(kwargs.pop("headers", None) or {})
    if _AGENTS_SERVICE_TOKEN:
        headers.setdefault("Authorization", f"Bearer {_AGENTS_SERVICE_TOKEN}")
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            return await client.request(method, url, headers=headers, **kwargs)
    except httpx.HTTPError as exc:
        logger.exception(
            "agents_proxy.request_failed",
            extra={
                "method": safe_log_value(method),
                "path": safe_log_value(safe_path),
            },
        )
        raise HTTPException(
            status_code=503,
            detail=f"Agents service unavailable: {exc}",
        ) from exc


async def _investigation_evidence(db: Any, cid: Any, tenant_id: Any) -> tuple[str, dict[str, Any]]:
    """Assemble what the forensic agent should reason over, from the case's alerts.

    The console used to send the literal string `"Investigate alert: <title>"`
    and nothing else, so the agent reasoned over a one-line title while
    auto-triage -- the same agent, the other entry point -- correctly passed
    the whole `raw_event`. Two paths into one investigator, one of them
    starved.

    The evidence was never missing. `aisoc_cases.alert_ids` is written at case
    creation and read by nothing, and `InvestigationRequest` on the agents
    side has always declared `raw_alert`. This reads the first and fills the
    second.

    Returns `(summary, raw_alert)`. `raw_alert` stays `{}` when the case has
    no alerts, which is honest: a case opened by hand has no telemetry, and
    inventing a shape would hand the groundedness gate something to certify.
    """
    case_row = (
        await db.execute(
            text("SELECT title, description, severity, alert_ids FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(
                id=cid, tenant_id=tenant_id
            )
        )
    ).fetchone()
    if case_row is None:
        return "", {}

    alert_ids = [str(a) for a in (case_row.alert_ids or [])]
    if not alert_ids:
        summary = f"{case_row.title}"
        if case_row.description:
            summary = f"{summary}\n\n{case_row.description}"
        return summary, {}

    # Bounded. A correlated case can carry hundreds of alerts and the prompt
    # has a budget; the newest are the ones an analyst is looking at.
    rows = (
        await db.execute(
            text(
                """
                SELECT id, title, description, severity, confidence, status,
                       connector_type, external_id, mitre_techniques, entities,
                       raw_event, created_at
                  FROM alerts
                 WHERE tenant_id = :tenant_id AND id = ANY(CAST(:ids AS uuid[]))
                 ORDER BY created_at DESC
                 LIMIT 25
                """
            ).bindparams(tenant_id=tenant_id, ids=alert_ids)
        )
    ).fetchall()

    alerts = [
        {
            "id": str(r.id),
            "title": r.title,
            "description": r.description,
            "severity": r.severity,
            "confidence": r.confidence,
            "status": r.status,
            "source": r.connector_type,
            "vendor_id": r.external_id,
            "mitre_techniques": list(r.mitre_techniques or []),
            "entities": r.entities or {},
            # The payload the connector actually delivered. This is the whole
            # point: everything above is our summary of it.
            "raw_event": r.raw_event or {},
            "observed_at": r.created_at.isoformat() if r.created_at else None,
        }
        for r in rows
    ]

    lines = [case_row.title]
    if case_row.description:
        lines.append(case_row.description)
    lines.append(f"{len(alerts)} correlated alert(s) on this case:")
    lines += [f"  - [{a['severity']}] {a['title']} (source: {a['source'] or 'unknown'})" for a in alerts]

    raw_alert: dict[str, Any] = {
        "case": {
            "id": str(cid),
            "title": case_row.title,
            "severity": case_row.severity,
        },
        "alerts": alerts,
        # Stated rather than implied: the agent and the groundedness gate both
        # need to know whether they are seeing everything.
        "alert_count": len(alert_ids),
        "alerts_included": len(alerts),
        "truncated": len(alert_ids) > len(alerts),
    }
    return "\n".join(lines), raw_alert


@router.post("/{case_id}/investigate", summary="Launch investigation for case")
async def case_investigate(
    case_id: str,
    body: InvestigateRequest,
    db: DBSession,
    user: Annotated[AuthUser, Depends(require_permission("cases:write"))],
) -> dict[str, Any]:
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    case_row = (
        await db.execute(
            text("SELECT alert_ids FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(id=cid, tenant_id=user.tenant_id)
        )
    ).fetchone()
    if not case_row:
        raise HTTPException(status_code=404, detail="Case not found.")
    case_alert_ids = [str(a) for a in (case_row.alert_ids or [])]

    # The evidence, assembled server-side from the case's own alerts rather
    # than taken from the caller. The console was sending the literal string
    # "Investigate alert: <title>", so the forensic agent reasoned over a
    # headline while auto-triage passed the whole raw event to the same code.
    #
    # Server-side because the browser does not hold the raw events and should
    # not be trusted with what the agent reasons over even if it did: an
    # attacker-influenced payload reaching a prompt is the injection surface
    # `PromptInjectionGuard` exists for, and narrowing it to data we loaded
    # ourselves is cheaper than guarding it.
    derived_summary, raw_alert = await _investigation_evidence(db, cid, user.tenant_id)
    # A caller-supplied summary is kept as a note rather than used in place of
    # the evidence, so an analyst can say why they are looking.
    summary = derived_summary
    if body.alert_summary:
        summary = f"{body.alert_summary}\n\n{derived_summary}" if derived_summary else body.alert_summary

    # Forward the authenticated tenant so the agents service attributes the run
    # to the real tenant instead of falling back to the "default" placeholder,
    # which the demo seed no longer maps to any tenant (issue #601). The ledger
    # is scoped by tenant_id, so without this the whole run is never persisted.
    # Service-token path requires the acting tenant on the header, not just
    # in the body: tenant_scope refuses a service token with no tenant.
    # The agents service stores raw_alert on the run and every downstream
    # agent reads it; forwarding {} meant the forensic/report models got an
    # empty payload and filled the gap with fabricated artefacts
    # (C:\\Windows\\Temp\\malware.exe and friends). Load the case's linked
    # alerts and pass their real content, truncated so the prompt stays
    # bounded and free of multi-MB raw blobs.
    raw_alert_payload: dict[str, Any] = {"case_id": str(cid)}
    try:
        if case_alert_ids:
            rows = (
                (
                    await db.execute(
                        text(
                            "SELECT id, title, description, severity, connector_type, "
                            "affected_ips, affected_hosts, affected_users, event_time, raw_event "
                            "FROM alerts WHERE id::text = ANY(:ids) AND tenant_id = :tenant_id "
                            "ORDER BY event_time DESC LIMIT 3"
                        ).bindparams(ids=case_alert_ids, tenant_id=user.tenant_id)
                    )
                )
                .mappings()
                .all()
            )
            alerts_out = []
            for r in rows:
                raw = r["raw_event"] if isinstance(r["raw_event"], dict) else {}
                full_log = raw.get("full_log") or ""
                alerts_out.append(
                    {
                        "id": str(r["id"]),
                        "title": r["title"],
                        "description": (r["description"] or "")[:1000],
                        "severity": r["severity"],
                        "source": r["connector_type"],
                        "affected_ips": list(r["affected_ips"] or [])[:20],
                        "affected_hosts": list(r["affected_hosts"] or [])[:20],
                        "affected_users": list(r["affected_users"] or [])[:20],
                        "event_time": r["event_time"].isoformat() if r["event_time"] else None,
                        "full_log": str(full_log)[:4000],
                    }
                )
            if alerts_out:
                raw_alert_payload["alerts"] = alerts_out
    except Exception:  # noqa: BLE001 - never block launch on enrichment
        logger.warning("investigate.launch.raw_alert_enrichment_failed case_id=%s", cid, exc_info=True)

    # Launching an agent investigation IS an analyst action: advance
    # new/triaged cases to 'investigating' in the same request so the
    # board reflects reality without a separate PATCH. Forward-only, same
    # ladder rule — a contained/resolved case is never pulled backwards
    # by a re-run.
    try:
        st_row = (
            await db.execute(
                text("SELECT status FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(
                    id=cid, tenant_id=user.tenant_id
                )
            )
        ).fetchone()
        if st_row and _forward_to_investigating_ok(st_row.status):
            await db.execute(
                text(
                    "UPDATE aisoc_cases SET status = 'investigating', updated_at = :now WHERE id = :id AND tenant_id = :tenant_id"
                ).bindparams(id=cid, tenant_id=user.tenant_id, now=datetime.now(UTC))
            )
            await db.commit()
    except Exception:  # noqa: BLE001 — never block the launch on the status bump
        await db.rollback()
        logger.warning("investigate.launch.status_advance_failed case_id=%s", cid, exc_info=True)

    # The same honesty applies to the alerts themselves: an alert under
    # agent investigation is not "new" anymore. Advance the case's linked
    # alerts to 'investigating' in the same request — forward-only, so
    # resolved/false-positive/closed alerts are never dragged backwards,
    # and alerts already further along (in_progress) are left alone.
    if case_alert_ids:
        try:
            bump = await db.execute(
                text(
                    "UPDATE alerts SET status = 'investigating', updated_at = :now "
                    "WHERE id::text = ANY(:ids) AND tenant_id = :tenant_id "
                    "AND status IN ({})".format(", ".join(f"'{st}'" for st in _ALERT_OPEN_STATUSES))
                ).bindparams(
                    ids=[str(a) for a in case_alert_ids],
                    tenant_id=user.tenant_id,
                    now=datetime.now(UTC),
                )
            )
            await db.commit()
            if bump.rowcount:
                logger.info(
                    "investigate.launch.alerts_advance case_id=%s alert_count=%s",
                    cid,
                    bump.rowcount,
                )
        except Exception:  # noqa: BLE001 — never block the launch on the alert bump
            await db.rollback()
            logger.warning("investigate.launch.alerts_advance_failed case_id=%s", cid, exc_info=True)

    from app.services import investigation_attack_context
    if investigation_attack_context.enabled():
        raw_alert_payload["attack_context_preparation"] = await investigation_attack_context.prepare_investigation_graph(
            db, user.tenant_id, case_id=cid,
        )

    resp = await _agents_proxy(
        "POST",
        f"/api/v1/cases/{cid}/investigate",
        json={
            "alert_summary": summary,
            "raw_alert": raw_alert_payload,
            "tenant_id": str(user.tenant_id),
        },
        headers={"X-AiSOC-Tenant-ID": str(user.tenant_id)},
    )
    if resp.status_code >= 400:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)
    return resp.json()


@router.get("/{case_id}/investigations", summary="List investigation runs for a case")
async def list_case_investigations(
    case_id: str,
    db: DBSession,
    user: AuthUser,
) -> dict[str, Any]:
    """List all investigation runs for a case.

    The agents service is the source of truth.  When it's unreachable we return
    an empty list rather than 503 so the case detail page still renders.
    """
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    try:
        resp = await _agents_proxy("GET", f"/api/v1/cases/{cid}/investigations", headers={"X-AiSOC-Tenant-ID": str(user.tenant_id)})
        if resp.status_code < 400:
            return resp.json()
    except HTTPException:
        # Deliberate: the fallback below is the handling. The comment lives
        # inside the clause because an explanation sitting after the block
        # reads as commentary on the next statement, and `py/empty-except`
        # cannot see it there either.
        pass
    # Agents service has no list route (or is unreachable) — fall back to the
    # local ledger, which every run persists to anyway.
    from app.models.investigation import InvestigationRun

    rows = (
        (
            await db.execute(
                select(InvestigationRun)
                .where(InvestigationRun.tenant_id == user.tenant_id)
                .where(InvestigationRun.case_id.in_([str(cid), str(case_id)]))
                .order_by(InvestigationRun.created_at.desc())
                .limit(20)
            )
        )
        .scalars()
        .all()
    )
    return {
        "runs": [
            {
                "run_id": str(r.id),
                "case_id": r.case_id,
                "status": r.status,
                "model": r.model_used,
                "iterations": r.iterations,
                "total_tokens": r.total_tokens,
                "started_at": r.started_at.isoformat() if r.started_at else None,
                "completed_at": r.completed_at.isoformat() if r.completed_at else None,
                "error": r.error,
            }
            for r in rows
        ]
    }


@router.get("/{case_id}/investigations/{run_id}", summary="Get investigation run")
async def case_investigation_run(
    case_id: str,
    run_id: str,
    db: DBSession,
    user: AuthUser,
) -> dict[str, Any]:
    """One investigation run belonging to this case, in the caller's tenant."""
    # Scoping kept out of the docstring because FastAPI publishes that verbatim
    # in docs/openapi.yaml, and the rationale is for the next maintainer rather
    # than for API consumers.
    #
    # This handler took no database session and never read `user.tenant_id`:
    # `case_id` was declared and never used, and `run_id` alone was proxied to
    # the agents service, so any authenticated user could read any run by id
    # across tenants (GHSA-x2gf-3p79-wvgm). The sibling list route two
    # functions up already resolved the case against the caller's tenant.
    #
    # Both halves below are needed. Resolving the case proves the caller may
    # see *this case*; checking the run belongs to it proves the id in the path
    # is not somebody else's run smuggled under a case the caller does own.
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    # UUID identifiers are parsed by _resolve_case_id without querying the
    # database, so this proxy must verify the Case just like local readers do.
    owned_case = (
        await db.execute(
            text("SELECT id FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(
                id=cid, tenant_id=user.tenant_id
            )
        )
    ).fetchone()
    if owned_case is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found.")
    # URL-encode the user-supplied run_id so it cannot inject `/`, `?`, `#`,
    # CR/LF, or other URL syntax into the proxied path.
    safe_run_id = quote(run_id, safe="")
    resp = await _agents_proxy("GET", f"/api/v1/investigations/{safe_run_id}", headers={"X-AiSOC-Tenant-ID": str(user.tenant_id)})
    if resp.status_code >= 400:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)
    run = resp.json()

    # A run that names a different case is not this case's run. Compared as
    # strings because the agents service echoes whatever case id it was given.
    run_case_id = run.get("case_id")
    if str(run_case_id) != str(cid):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Investigation run not found for this case")
    return run


@router.get(
    "/{case_id}/investigations/{run_id}/report.md",
    response_class=PlainTextResponse,
    summary="Markdown incident report for one investigation run",
)
async def case_investigation_report_md(
    case_id: str,
    run_id: str,
    db: DBSession,
    user: AuthUser,
) -> PlainTextResponse:
    """The Markdown report the case workspace renders."""
    # `CaseWorkspace.tsx` fetched this from two places and the route did not
    # exist, so the report pane was permanently empty. The agents service has
    # served `/api/v1/investigations/{run_id}/report.md` all along; nothing
    # proxied it.
    #
    # Reuse the status route's Case + Run ownership checks before fetching
    # report bytes; resolving a UUID alone does not establish Case ownership.
    await case_investigation_run(case_id=case_id, run_id=run_id, db=db, user=user)
    safe_run_id = quote(run_id, safe="")

    resp = await _agents_proxy("GET", f"/api/v1/investigations/{safe_run_id}/report.md", headers={"X-AiSOC-Tenant-ID": str(user.tenant_id)})
    if resp.status_code >= 400:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)
    return PlainTextResponse(content=resp.text, media_type="text/markdown; charset=utf-8")


# Filename sanitiser for Content-Disposition: keep only safe ASCII so the
# header cannot be split with CR/LF and the value renders consistently.
_SAFE_FILENAME_RE = re.compile(r"[^A-Za-z0-9._-]")


def _safe_filename_segment(value: str) -> str:
    """Reduce an identifier to a Content-Disposition-safe filename segment."""
    return _SAFE_FILENAME_RE.sub("_", value)[:64] or "unknown"


# ────────────────────────────────────────────────────────────────────────────
# WS-D2 — auto-summary artifact at investigation close.
# ────────────────────────────────────────────────────────────────────────────

# We keep the breadcrumb body in one place so the system note stays uniform
# across deployments — easier to grep, easier to redact in CI exports.
_SUMMARY_BREADCRUMB_BODY = (
    "Case auto-summary generated. Download from "
    "/api/v1/cases/{case_id}/summary?format=html "
    "(or ?format=json for the structured payload). "
    "For the blameless retrospective, fetch "
    "/api/v1/cases/{case_id}/postmortem?format=html. "
    "Print either page (Ctrl/Cmd-P → Save as PDF) for the runbook archive."
)


async def _emit_summary_breadcrumb(
    db: Any,
    *,
    case_id: uuid.UUID,
    tenant_id: uuid.UUID | str,
    status: str,
) -> None:
    """Drop a system comment pointing to the on-demand summary endpoint.

    Idempotent on repeated status changes — we re-emit only when transitioning
    *into* a terminal state, never on noop updates. The body intentionally
    avoids embedding tenant-specific URLs so the artifact link still works
    behind reverse proxies that rewrite the host.
    """
    body = _SUMMARY_BREADCRUMB_BODY.format(case_id=case_id) + f" (status={status})"
    await db.execute(
        text(
            """
            INSERT INTO aisoc_case_comments
                (id, case_id, tenant_id, author, body, is_system, created_at)
            VALUES (:id, :case_id, :tenant_id, :author, :body, true, :now)
            """
        ).bindparams(
            id=uuid.uuid4(),
            case_id=case_id,
            tenant_id=tenant_id,
            author="aisoc",
            body=body,
            now=datetime.now(UTC),
        )
    )
    await db.commit()


@router.get(
    "/{case_id}/summary",
    summary="Download the per-case auto-summary (JSON or HTML)",
    response_model=None,
)
async def case_auto_summary(
    case_id: str,
    db: DBSession,
    user: AuthUser,
    format: Literal["json", "html"] = Query(
        "json",
        description=(
            "Response format. ``json`` returns the structured CaseAutoSummary; "
            "``html`` returns a print-ready report (use the browser's "
            "Save-as-PDF affordance for archival)."
        ),
    ),
) -> Any:
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    summary = await build_case_summary(db, cid, user.tenant_id)
    if summary is None:
        raise HTTPException(status_code=404, detail="Case not found.")

    if format == "html":
        # The logo is inlined because this document is saved as a PDF and
        # archived. A referenced asset makes the archived copy depend on the
        # deployment still serving that URL years later.
        branding = await resolve_branding(db, user.tenant_id, inline_logo=True)
        rendered = render_case_summary_html(summary, branding)
        case_label = summary.case.case_number or str(summary.case.case_id)[:8]
        filename = _safe_filename_segment(f"case-{case_label}-summary") + ".html"
        return HTMLResponse(
            content=rendered,
            headers={"Content-Disposition": f'inline; filename="{filename}"'},
        )

    return summary


@router.get(
    "/{case_id}/postmortem",
    summary="Download the per-case blameless post-mortem (JSON or HTML)",
    response_model=None,
)
async def case_auto_postmortem(
    case_id: str,
    db: DBSession,
    user: AuthUser,
    format: Literal["json", "html"] = Query(
        "json",
        description=(
            "Response format. ``json`` returns the structured CasePostmortem; "
            "``html`` returns a print-ready blameless retrospective (use the "
            "browser's Save-as-PDF affordance for the runbook archive)."
        ),
    ),
) -> Any:
    """Generate a deterministic blameless post-mortem for one case.

    Distinct from ``/summary``: the summary is a snapshot of *what the case
    looks like right now*; the post-mortem is a retrospective oriented around
    *what happened, when did we find out, what did we do, and what should we
    change*. Both are deterministic — same case state in, same artefact out.
    """
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    postmortem = await build_case_postmortem(db, cid, user.tenant_id)
    if postmortem is None:
        raise HTTPException(status_code=404, detail="Case not found.")

    if format == "html":
        rendered = render_case_postmortem_html(postmortem)
        case_label = postmortem.case.case_number or str(postmortem.case.case_id)[:8]
        filename = _safe_filename_segment(f"case-{case_label}-postmortem") + ".html"
        return HTMLResponse(
            content=rendered,
            headers={"Content-Disposition": f'inline; filename="{filename}"'},
        )

    return postmortem


@router.get(
    "/{case_id}/investigations/{run_id}/report.pdf",
    summary="Download investigation PDF report",
)
async def case_investigation_pdf(
    case_id: str,
    run_id: str,
    db: DBSession,
    user: AuthUser,
) -> Response:
    # Apply the same case + run ownership check as the status/Markdown routes
    # before requesting report bytes from Agents.
    await case_investigation_run(case_id=case_id, run_id=run_id, db=db, user=user)
    safe_run_id = quote(run_id, safe="")
    resp = await _agents_proxy(
        "GET",
        f"/api/v1/investigations/{safe_run_id}/report.pdf",
        headers={"X-AiSOC-Tenant-ID": str(user.tenant_id)},
    )
    if resp.status_code >= 400:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)
    safe_case_id = _safe_filename_segment(case_id)
    safe_run_id_filename = _safe_filename_segment(run_id)
    return Response(
        content=resp.content,
        media_type=resp.headers.get("content-type", "application/pdf"),
        headers={
            "Content-Disposition": resp.headers.get(
                "content-disposition",
                f'attachment; filename="case-{safe_case_id}-{safe_run_id_filename}.pdf"',
            ),
        },
    )


@router.get("/{case_id}/related", summary="List related cases (by alert/observable overlap)")
async def list_related_cases(
    case_id: str,
    db: DBSession,
    user: AuthUser,
) -> dict[str, Any]:
    """Return other cases that share alerts or observables with this case.

    This is intentionally a lightweight heuristic — we look for cases that
    overlap on `alert_ids` or share an observable IP/host.  It's the smallest
    thing the case detail page needs to stop 404'ing.
    """
    cid = await _resolve_case_id(case_id, db, user.tenant_id)
    row = (
        await db.execute(
            text("SELECT alert_ids, observable_graph FROM aisoc_cases WHERE id = :id AND tenant_id = :tenant_id").bindparams(
                id=cid, tenant_id=user.tenant_id
            )
        )
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Case not found.")

    alert_ids = list(row.alert_ids or [])
    related: list[dict[str, Any]] = []

    if alert_ids:
        rows = (
            await db.execute(
                text(
                    """
                    SELECT id, case_number, title, severity, status, created_at
                    FROM aisoc_cases
                    WHERE id <> :id
                      AND tenant_id = :tenant_id
                      AND alert_ids && CAST(:alerts AS UUID[])
                    ORDER BY created_at DESC
                    LIMIT 20
                    """
                ).bindparams(
                    id=cid,
                    tenant_id=user.tenant_id,
                    alerts=[str(a) for a in alert_ids],
                )
            )
        ).fetchall()
        for r in rows:
            related.append(
                {
                    "id": str(r.id),
                    "case_number": r.case_number,
                    "title": r.title,
                    "severity": r.severity or "medium",
                    "status": r.status or "new",
                    "created_at": r.created_at.isoformat() if r.created_at else None,
                    "reason": "shared_alerts",
                }
            )

    return {"related": related}
